(self["webpackChunkstreamoze_vue_front"] = self["webpackChunkstreamoze_vue_front"] || []).push([[64], {
    6700: function(s, t, e) {
        var i = {
            "./af": 3906,
            "./af.js": 3906,
            "./ar": 902,
            "./ar-dz": 3853,
            "./ar-dz.js": 3853,
            "./ar-kw": 299,
            "./ar-kw.js": 299,
            "./ar-ly": 6825,
            "./ar-ly.js": 6825,
            "./ar-ma": 6379,
            "./ar-ma.js": 6379,
            "./ar-sa": 7700,
            "./ar-sa.js": 7700,
            "./ar-tn": 2059,
            "./ar-tn.js": 2059,
            "./ar.js": 902,
            "./az": 6043,
            "./az.js": 6043,
            "./be": 7936,
            "./be.js": 7936,
            "./bg": 4078,
            "./bg.js": 4078,
            "./bm": 4014,
            "./bm.js": 4014,
            "./bn": 9554,
            "./bn-bd": 7114,
            "./bn-bd.js": 7114,
            "./bn.js": 9554,
            "./bo": 6529,
            "./bo.js": 6529,
            "./br": 5437,
            "./br.js": 5437,
            "./bs": 9647,
            "./bs.js": 9647,
            "./ca": 9951,
            "./ca.js": 9951,
            "./cs": 6113,
            "./cs.js": 6113,
            "./cv": 7965,
            "./cv.js": 7965,
            "./cy": 5858,
            "./cy.js": 5858,
            "./da": 3515,
            "./da.js": 3515,
            "./de": 2831,
            "./de-at": 6263,
            "./de-at.js": 6263,
            "./de-ch": 1127,
            "./de-ch.js": 1127,
            "./de.js": 2831,
            "./dv": 4510,
            "./dv.js": 4510,
            "./el": 8616,
            "./el.js": 8616,
            "./en-au": 4595,
            "./en-au.js": 4595,
            "./en-ca": 3545,
            "./en-ca.js": 3545,
            "./en-gb": 9609,
            "./en-gb.js": 9609,
            "./en-ie": 3727,
            "./en-ie.js": 3727,
            "./en-il": 3302,
            "./en-il.js": 3302,
            "./en-in": 6305,
            "./en-in.js": 6305,
            "./en-nz": 9128,
            "./en-nz.js": 9128,
            "./en-sg": 4569,
            "./en-sg.js": 4569,
            "./eo": 650,
            "./eo.js": 650,
            "./es": 6358,
            "./es-do": 4214,
            "./es-do.js": 4214,
            "./es-mx": 8639,
            "./es-mx.js": 8639,
            "./es-us": 232,
            "./es-us.js": 232,
            "./es.js": 6358,
            "./et": 7279,
            "./et.js": 7279,
            "./eu": 5515,
            "./eu.js": 5515,
            "./fa": 7981,
            "./fa.js": 7981,
            "./fi": 7090,
            "./fi.js": 7090,
            "./fil": 9208,
            "./fil.js": 9208,
            "./fo": 2799,
            "./fo.js": 2799,
            "./fr": 3463,
            "./fr-ca": 2213,
            "./fr-ca.js": 2213,
            "./fr-ch": 2848,
            "./fr-ch.js": 2848,
            "./fr.js": 3463,
            "./fy": 1468,
            "./fy.js": 1468,
            "./ga": 8163,
            "./ga.js": 8163,
            "./gd": 2898,
            "./gd.js": 2898,
            "./gl": 6312,
            "./gl.js": 6312,
            "./gom-deva": 682,
            "./gom-deva.js": 682,
            "./gom-latn": 9178,
            "./gom-latn.js": 9178,
            "./gu": 5009,
            "./gu.js": 5009,
            "./he": 2795,
            "./he.js": 2795,
            "./hi": 7009,
            "./hi.js": 7009,
            "./hr": 6506,
            "./hr.js": 6506,
            "./hu": 9565,
            "./hu.js": 9565,
            "./hy-am": 3864,
            "./hy-am.js": 3864,
            "./id": 5626,
            "./id.js": 5626,
            "./is": 6649,
            "./is.js": 6649,
            "./it": 151,
            "./it-ch": 5348,
            "./it-ch.js": 5348,
            "./it.js": 151,
            "./ja": 9830,
            "./ja.js": 9830,
            "./jv": 3751,
            "./jv.js": 3751,
            "./ka": 3365,
            "./ka.js": 3365,
            "./kk": 5980,
            "./kk.js": 5980,
            "./km": 9571,
            "./km.js": 9571,
            "./kn": 5880,
            "./kn.js": 5880,
            "./ko": 6809,
            "./ko.js": 6809,
            "./ku": 6773,
            "./ku.js": 6773,
            "./ky": 5505,
            "./ky.js": 5505,
            "./lb": 553,
            "./lb.js": 553,
            "./lo": 1237,
            "./lo.js": 1237,
            "./lt": 1563,
            "./lt.js": 1563,
            "./lv": 1057,
            "./lv.js": 1057,
            "./me": 6495,
            "./me.js": 6495,
            "./mi": 3096,
            "./mi.js": 3096,
            "./mk": 3874,
            "./mk.js": 3874,
            "./ml": 6055,
            "./ml.js": 6055,
            "./mn": 7747,
            "./mn.js": 7747,
            "./mr": 7113,
            "./mr.js": 7113,
            "./ms": 8687,
            "./ms-my": 7948,
            "./ms-my.js": 7948,
            "./ms.js": 8687,
            "./mt": 4532,
            "./mt.js": 4532,
            "./my": 4655,
            "./my.js": 4655,
            "./nb": 6961,
            "./nb.js": 6961,
            "./ne": 2512,
            "./ne.js": 2512,
            "./nl": 8448,
            "./nl-be": 2936,
            "./nl-be.js": 2936,
            "./nl.js": 8448,
            "./nn": 9031,
            "./nn.js": 9031,
            "./oc-lnc": 5174,
            "./oc-lnc.js": 5174,
            "./pa-in": 118,
            "./pa-in.js": 118,
            "./pl": 3448,
            "./pl.js": 3448,
            "./pt": 3518,
            "./pt-br": 2447,
            "./pt-br.js": 2447,
            "./pt.js": 3518,
            "./ro": 817,
            "./ro.js": 817,
            "./ru": 262,
            "./ru.js": 262,
            "./sd": 8990,
            "./sd.js": 8990,
            "./se": 3842,
            "./se.js": 3842,
            "./si": 7711,
            "./si.js": 7711,
            "./sk": 756,
            "./sk.js": 756,
            "./sl": 3772,
            "./sl.js": 3772,
            "./sq": 6187,
            "./sq.js": 6187,
            "./sr": 732,
            "./sr-cyrl": 5713,
            "./sr-cyrl.js": 5713,
            "./sr.js": 732,
            "./ss": 9455,
            "./ss.js": 9455,
            "./sv": 9770,
            "./sv.js": 9770,
            "./sw": 959,
            "./sw.js": 959,
            "./ta": 6459,
            "./ta.js": 6459,
            "./te": 5302,
            "./te.js": 5302,
            "./tet": 7975,
            "./tet.js": 7975,
            "./tg": 1294,
            "./tg.js": 1294,
            "./th": 2385,
            "./th.js": 2385,
            "./tk": 4613,
            "./tk.js": 4613,
            "./tl-ph": 8668,
            "./tl-ph.js": 8668,
            "./tlh": 8190,
            "./tlh.js": 8190,
            "./tr": 4506,
            "./tr.js": 4506,
            "./tzl": 3440,
            "./tzl.js": 3440,
            "./tzm": 9852,
            "./tzm-latn": 2350,
            "./tzm-latn.js": 2350,
            "./tzm.js": 9852,
            "./ug-cn": 730,
            "./ug-cn.js": 730,
            "./uk": 99,
            "./uk.js": 99,
            "./ur": 2100,
            "./ur.js": 2100,
            "./uz": 6002,
            "./uz-latn": 6322,
            "./uz-latn.js": 6322,
            "./uz.js": 6002,
            "./vi": 4207,
            "./vi.js": 4207,
            "./x-pseudo": 4674,
            "./x-pseudo.js": 4674,
            "./yo": 570,
            "./yo.js": 570,
            "./zh-cn": 3644,
            "./zh-cn.js": 3644,
            "./zh-hk": 2591,
            "./zh-hk.js": 2591,
            "./zh-mo": 9503,
            "./zh-mo.js": 9503,
            "./zh-tw": 8080,
            "./zh-tw.js": 8080
        };
        function a(s) {
            var t = n(s);
            return e(t)
        }
        function n(s) {
            if (!e.o(i, s)) {
                var t = new Error("Cannot find module '" + s + "'");
                throw t.code = "MODULE_NOT_FOUND",
                t
            }
            return i[s]
        }
        a.keys = function() {
            return Object.keys(i)
        }
        ,
        a.resolve = n,
        s.exports = a,
        a.id = 6700
    },
    4582: function(s, t, e) {
        "use strict";
        e.d(t, {
            m: function() {
                return _c
            }
        });
        var i = e(9242)
          , a = e(1020)
          , n = e(3396);
        function l(s, t, e, i, a, l) {
            const c = (0,
            n.up)("HomeFeaturedList")
              , r = (0,
            n.up)("HomeFeaturedLoading");
            return (0,
            n.wg)(),
            (0,
            n.j4)(n.n4, null, {
                default: (0,
                n.w5)((()=>[(0,
                n.Wm)(c)])),
                fallback: (0,
                n.w5)((()=>[(0,
                n.Wm)(r)])),
                _: 1
            })
        }
        const c = {
            class: "section-wrap is-focus"
        }
          , r = {
            class: "container"
        }
          , o = {
            class: "sblock home-upcoming"
        }
          , d = (0,
        n._)("div", {
            class: "sblock-header"
        }, [(0,
        n._)("div", {
            class: "sblock-header-title"
        }, [(0,
        n._)("h3", {
            class: "headingA1 l-title"
        }, "Upcoming...")])], -1)
          , m = {
            class: "sblock-body"
        }
          , v = {
            key: 0,
            class: "match-list match-grid large-match-grid"
        }
          , u = {
            key: 1,
            class: "blank-more"
        }
          , h = (0,
        n.uE)('<div class="blank-more-text text-center p-5"><div>No match to display</div></div><div class="d-flex justify-content-between"><div class="b-more-loading"></div><div class="b-more-loading"></div><div class="b-more-loading"></div><div class="b-more-loading"></div><div class="b-more-loading"></div></div>', 2)
          , _ = [h];
        function g(s, t, e, i, a, l) {
            const h = (0,
            n.up)("MatchFeaturedItem");
            return (0,
            n.wg)(),
            (0,
            n.iD)("div", c, [(0,
            n._)("div", r, [(0,
            n._)("section", o, [d, (0,
            n._)("div", m, [i.matches && i.matches.length > 0 ? ((0,
            n.wg)(),
            (0,
            n.iD)("div", v, [((0,
            n.wg)(!0),
            (0,
            n.iD)(n.HY, null, (0,
            n.Ko)(i.matches, (s=>((0,
            n.wg)(),
            (0,
            n.j4)(h, {
                key: s.id,
                "model-id": s.id
            }, null, 8, ["model-id"])))), 128))])) : ((0,
            n.wg)(),
            (0,
            n.iD)("div", u, _))])])])])
        }
        var w = e(4870)
          , p = e(4806)
          , y = e(2482)
          , f = (e(7658),
        e(6797))
          , b = e.n(f);
        const k = {
            LIVE: 1,
            PENDING: 2,
            INTERRUPTED: 3,
            DELAY: 4,
            POSTPONED: 5,
            FINISHED: 8,
            CANCELED: 9
        };
        class j {
            constructor(s) {
                (0,
                y.Z)(this, "type", void 0),
                (0,
                y.Z)(this, "home", void 0),
                (0,
                y.Z)(this, "away", void 0),
                Object.assign(this, s)
            }
            get can_show() {
                switch (this.type) {
                case 25:
                    return !0;
                case 24:
                    return !1;
                case 23:
                    return !1;
                case 22:
                    return !1;
                case 21:
                    return !0;
                case 8:
                    return !1;
                case 4:
                    return "Red card";
                case 3:
                    return !1;
                case 2:
                    return !0
                }
                return !1
            }
            get description() {
                switch (this.type) {
                case 25:
                    return "Ball Possession";
                case 24:
                    return "Dangerous Attack";
                case 23:
                    return "Attacks";
                case 22:
                    return "Shots off target";
                case 21:
                    return "Shots on target";
                case 8:
                    return "Penalty";
                case 4:
                    return "Red card";
                case 3:
                    return "Yellow card";
                case 2:
                    return "Corner"
                }
                return this.type
            }
            get home_value() {
                return 25 === this.type ? `${this.home}%` : this.home
            }
            get away_value() {
                return 25 === this.type ? `${this.away}%` : this.away
            }
        }
        class D {
            constructor(s) {
                if ((0,
                y.Z)(this, "id", void 0),
                (0,
                y.Z)(this, "name", void 0),
                (0,
                y.Z)(this, "slug", void 0),
                (0,
                y.Z)(this, "timestamp", void 0),
                (0,
                y.Z)(this, "red_cards", void 0),
                (0,
                y.Z)(this, "home", void 0),
                (0,
                y.Z)(this, "away", void 0),
                (0,
                y.Z)(this, "tournament", void 0),
                (0,
                y.Z)(this, "round", void 0),
                (0,
                y.Z)(this, "scores", void 0),
                (0,
                y.Z)(this, "win_code", void 0),
                (0,
                y.Z)(this, "match_status", void 0),
                (0,
                y.Z)(this, "sport_type", void 0),
                (0,
                y.Z)(this, "has_lineup", void 0),
                (0,
                y.Z)(this, "has_tracker", void 0),
                (0,
                y.Z)(this, "priority", void 0),
                (0,
                y.Z)(this, "agg_score", void 0),
                (0,
                y.Z)(this, "environment", void 0),
                (0,
                y.Z)(this, "is_featured", void 0),
                (0,
                y.Z)(this, "thumbnail_url", void 0),
                (0,
                y.Z)(this, "commentators", void 0),
                (0,
                y.Z)(this, "play_urls", void 0),
                (0,
                y.Z)(this, "venue", void 0),
                (0,
                y.Z)(this, "referee", void 0),
                (0,
                y.Z)(this, "season", void 0),
                (0,
                y.Z)(this, "is_live", void 0),
                (0,
                y.Z)(this, "time_str", void 0),
                (0,
                y.Z)(this, "stats", void 0),
                (0,
                y.Z)(this, "_url", void 0),
                (0,
                y.Z)(this, "_origin", void 0),
                s.stats)
                    try {
                        s.stats = s.stats.map((s=>new j(s)))
                    } catch (t) {}
                Object.assign(this, s),
                this._origin = s
            }
            get date() {
                return b()(this.timestamp).format("YYYYMMDD")
            }
            get start_time() {
                return b()(this.timestamp).format("HH:mm")
            }
            get start_date() {
                return b()(this.timestamp).format("DD/MM/YYYY")
            }
            get full_date_time() {
                return b()(this.timestamp).format("DD/MM/YYYY HH:mm")
            }
            get full_tournament_round() {
                let s = this.tournament.name;
                return this.round && (this.round.group ? s += ` - GROUP ${this.round.group}` : this.round.round && (s += ` - ROUND ${this.round.round}`)),
                s
            }
            getScore(s) {
                let t = "-";
                switch (this.match_status) {
                case k.CANCELED:
                case k.DELAY:
                case k.POSTPONED:
                case k.INTERRUPTED:
                    t = "";
                    break;
                case k.PENDING:
                    t = "-";
                    break;
                default:
                    t = "home" === s ? `${this.scores.home}` : `${this.scores.away}`
                }
                return t
            }
            get home_score() {
                return this.getScore("home")
            }
            get away_score() {
                return this.getScore("away")
            }
            get url() {
                return this._url ? this._url : window.build_match_url(this)
            }
            isEnd() {
                return this.match_status === k.FINISHED
            }
            isLive() {
                return this.match_status !== k.FINISHED && (this.match_status === k.LIVE || (!(this.match_status !== k.PENDING || !this.play_urls || !this.play_urls.length) || !0 === this.is_live))
            }
            isCancel() {
                switch (this.match_status) {
                case k.CANCELED:
                    return !0;
                default:
                    return !1
                }
            }
            get home_red_cards_arr() {
                let s = [];
                for (let t = 0; t < this.red_cards.home; t++)
                    s.push(1);
                return s
            }
            get away_red_cards_arr() {
                let s = [];
                for (let t = 0; t < this.red_cards.away; t++)
                    s.push(t);
                return s
            }
            get caster_name() {
                if (this.commentators && this.commentators.length > 0) {
                    let s = this.commentators.map((s=>s.name));
                    return s.join(" - ")
                }
                return ""
            }
            formatTime(s) {
                return b()(this.timestamp).format(s)
            }
            get venue_name() {
                return this.venue && this.venue.name ? this.venue.name : null
            }
            get has_stats() {
                return !!(this.stats && Array.isArray(this.stats) && this.stats.length > 0)
            }
        }
        var H = e(70)
          , z = e(6423);
        class x {
            static init(s) {
                self.vueInstance || (x.vueInstance = s,
                x.vueInstance.use(z.Z, H.ZP),
                x.vueInstance.axios.defaults.baseURL = window.api_base_url,
                x.vueInstance.axios.defaults.withCredentials = !0)
            }
            static query(s, t) {
                return x.vueInstance.axios.get(s, t)
            }
            static get(s) {
                return x.vueInstance.axios.get(`${s}`)
            }
            static post(s, t) {
                return x.vueInstance.axios.post(`${s}`, t)
            }
        }
        (0,
        y.Z)(x, "vueInstance", void 0);
        class Z {
            static async fetchFeatured() {
                try {
                    const s = await x.get("/v1/match/featured");
                    return s.data.data.map((s=>new D(s)))
                } catch (s) {
                    console.error(s)
                }
            }
            static async fetchRelated(s) {
                try {
                    const t = await x.get("/v1/match/related")
                      , e = [];
                    return t.data.data.map((t=>{
                        if (e.length < 10) {
                            const i = new D(t);
                            i.id !== s && e.push(i)
                        }
                    }
                    )),
                    e
                } catch (t) {
                    console.error(t)
                }
            }
            static async fetchResult() {
                try {
                    const s = await x.get("/v1/match/result");
                    return s.data.data.map((s=>new D(s)))
                } catch (s) {
                    console.error(s)
                }
            }
            static async fetchLive() {
                try {
                    const s = await x.get(`${window.api_live_base_url}/v1/match/live`);
                    return s.data.data.map((s=>new D(s)))
                } catch (s) {
                    console.error(s)
                }
            }
            static async fetchFixture(s) {
                try {
                    const t = await x.get(`/v1/match/fixture/${s}`);
                    return t.data.data.map((s=>new D(s)))
                } catch (t) {
                    console.error(t)
                }
            }
            static async fetchDetail(s) {
                try {
                    const t = await x.get(`/v1/match/${s}`);
                    return t.data.data ? new D(t.data.data) : null
                } catch (t) {
                    console.error(t)
                }
            }
            static async fetchStream(s) {
                try {
                    const t = await x.get(`/v1/match/${s}/stream`);
                    return t.data.data ? t.data.data : null
                } catch (t) {
                    console.error(t)
                }
            }
        }
        const S = (0,
        a.Q_)("match_db", (()=>{
            const s = (0,
            w.iH)({})
              , t = (0,
            w.iH)(null)
              , e = (0,
            w.iH)(!1)
              , i = (0,
            w.iH)(null);
            function a(t, e) {
                if (t) {
                    let a = null;
                    a = t instanceof D ? t : new D(t);
                    try {
                        if (s.value[a.id]) {
                            const t = s.value[a.id];
                            try {
                                t.has_stats && !a.has_stats && (a.stats = t.stats)
                            } catch (i) {
                                console.error(i)
                            }
                            e && "live" !== e.source && (a.time_str = t.time_str,
                            a.scores = t.scores,
                            a.match_status !== k.PENDING && a.match_status !== k.LIVE || [k.CANCELED, k.DELAY, k.POSTPONED, k.INTERRUPTED].indexOf(t.match_status) < 0 && (a.match_status = t.match_status,
                            a.scores = t.scores)),
                            a = new D({
                                ...t._origin,
                                ...a._origin
                            })
                        }
                    } catch (i) {
                        console.error(i)
                    }
                    s.value[a.id] = a
                }
            }
            function n(s, t) {
                s && (Array.isArray(s) ? s.map((s=>{
                    a(s, t)
                }
                )) : a(s, t))
            }
            function l(s) {
                let e = s.map((s=>{
                    let t = null;
                    return t = s instanceof D ? s : new D(s),
                    t
                }
                ));
                e = p.filter(e, (function(s) {
                    return s && s.isLive()
                }
                )),
                e = p.orderBy(e, ["timestamp"], ["asc"]),
                t.value = e
            }
            async function c() {
                try {
                    let s = await Z.fetchLive();
                    n(s, {
                        source: "live"
                    }),
                    l(s)
                } catch (s) {
                    console.error(s)
                }
            }
            function r() {
                e.value = !0,
                i.value || (c().then(),
                i.value = setInterval((function() {
                    e.value && c().then()
                }
                ), 3e4))
            }
            function o() {
                e.value = !1,
                i.value && (clearInterval(i.value),
                i.value = null)
            }
            return r(),
            {
                live_fixtures: t,
                db: s,
                addData: n,
                startSync: r,
                stopSync: o,
                syncLive: c
            }
        }
        ));
        var M = e(7139);
        const C = {
            class: "item-header"
        }
          , I = {
            class: "teams-logo"
        }
          , E = {
            class: "team-logo is-home"
        }
          , L = {
            class: "team-logo is-away"
        }
          , P = {
            key: 0,
            class: "detail"
        }
          , T = {
            class: "time"
        }
          , Y = (0,
        n._)("div", {
            class: "live-stick mr-2"
        }, [(0,
        n._)("i", {
            class: "icon-s-circle mr-1"
        }), (0,
        n.Uk)("LIVE ")], -1)
          , F = {
            key: 0,
            class: "onair"
        }
          , N = {
            key: 0,
            class: "time"
        }
          , A = {
            class: "coming"
        }
          , W = {
            key: 1,
            class: "detail"
        }
          , R = {
            class: "time"
        }
          , U = {
            class: "coming"
        }
          , B = {
            class: "sub"
        }
          , O = {
            class: "item-body"
        }
          , $ = {
            class: "detail-league"
        }
          , q = {
            class: "detail-match"
        }
          , K = {
            class: "team-line is-home"
        }
          , V = {
            class: "team-name"
        }
          , J = {
            class: "name"
        }
          , G = {
            class: "cards"
        }
          , Q = {
            class: "team-goal"
        }
          , X = {
            class: "team-line"
        }
          , ss = {
            class: "team-name is-away"
        }
          , ts = {
            class: "name"
        }
          , es = {
            class: "cards"
        }
          , is = {
            class: "team-goal"
        };
        function as(s, t, e, i, a, l) {
            const c = (0,
            n.up)("custom-link")
              , r = (0,
            n.up)("custom-image");
            return (0,
            n.wg)(),
            (0,
            n.iD)("div", {
                class: (0,
                M.C_)(["item-match item-football", {
                    "item-end": l.item.isEnd(),
                    "item-live": l.item.isLive()
                }])
            }, [(0,
            n.Wm)(c, {
                href: l.item.url,
                class: "match-link"
            }, null, 8, ["href"]), (0,
            n._)("div", C, [(0,
            n._)("div", I, [(0,
            n._)("div", E, [(0,
            n.Wm)(r, {
                src: l.item.home.logo
            }, null, 8, ["src"])]), (0,
            n._)("div", L, [(0,
            n.Wm)(r, {
                src: l.item.away.logo
            }, null, 8, ["src"])])]), l.item.isLive() ? ((0,
            n.wg)(),
            (0,
            n.iD)("div", P, [(0,
            n._)("div", T, [Y, 1 === l.item.match_status ? ((0,
            n.wg)(),
            (0,
            n.iD)("span", F, (0,
            M.zw)(l.item.time_str), 1)) : (0,
            n.kq)("", !0)]), 1 !== l.item.match_status ? ((0,
            n.wg)(),
            (0,
            n.iD)("div", N, [(0,
            n._)("div", A, (0,
            M.zw)(l.item.start_time), 1)])) : (0,
            n.kq)("", !0)])) : ((0,
            n.wg)(),
            (0,
            n.iD)("div", W, [(0,
            n._)("div", R, [(0,
            n._)("span", U, (0,
            M.zw)(l.item.start_time), 1)]), (0,
            n._)("div", B, (0,
            M.zw)(l.item.start_date), 1)]))]), (0,
            n._)("div", O, [(0,
            n._)("div", $, (0,
            M.zw)(l.item.full_tournament_round), 1), (0,
            n._)("div", q, [(0,
            n._)("div", K, [(0,
            n._)("div", V, [(0,
            n._)("h4", J, (0,
            M.zw)(l.item.home.name), 1), (0,
            n._)("div", G, [((0,
            n.wg)(!0),
            (0,
            n.iD)(n.HY, null, (0,
            n.Ko)(l.item.home_red_cards_arr, (s=>((0,
            n.wg)(),
            (0,
            n.iD)("div", {
                class: "red-card",
                key: s
            })))), 128))])]), (0,
            n._)("div", Q, (0,
            M.zw)(l.item.home_score), 1)]), (0,
            n._)("div", X, [(0,
            n._)("div", ss, [(0,
            n._)("h4", ts, (0,
            M.zw)(l.item.away.name), 1), (0,
            n._)("div", es, [((0,
            n.wg)(!0),
            (0,
            n.iD)(n.HY, null, (0,
            n.Ko)(l.item.away_red_cards_arr, (s=>((0,
            n.wg)(),
            (0,
            n.iD)("div", {
                class: "red-card",
                key: s
            })))), 128))])]), (0,
            n._)("div", is, (0,
            M.zw)(l.item.away_score), 1)])])])], 2)
        }
        var ns = {
            name: "MatchFeaturedItem",
            props: ["modelId"],
            setup() {
                const s = S();
                return {
                    store: s
                }
            },
            computed: {
                item() {
                    return this.store.db[this.modelId]
                }
            }
        }
          , ls = e(89);
        const cs = (0,
        ls.Z)(ns, [["render", as]]);
        var rs = cs
          , os = {
            name: "HomeFeaturedList",
            components: {
                MatchFeaturedItem: rs
            },
            async setup() {
                const s = S()
                  , t = (0,
                w.iH)([])
                  , e = async()=>{
                    let e = await Z.fetchFeatured();
                    s.addData(e, {
                        source: "featured"
                    }),
                    t.value = e
                }
                ;
                await e();
                const i = setInterval((function() {
                    e()
                }
                ), 3e5);
                return {
                    iFeatured: i,
                    matches: t,
                    store: s
                }
            },
            async mounted() {},
            beforeUnmount() {
                try {
                    this.iFeatured && clearInterval(this.iFeatured)
                } catch (s) {}
            }
        };
        const ds = (0,
        ls.Z)(os, [["render", g]]);
        var ms = ds;
        const vs = {
            class: "section-wrap is-focus"
        }
          , us = (0,
        n.uE)('<div class="container"><section class="sblock home-upcoming"><div class="sblock-header"><div class="sblock-header-title"><h3 class="headingA1 l-title">Upcoming...</h3></div></div><div class="sblock-body"><div class="ajax-loading is-load-focus"><div class="vir-item"></div><div class="vir-item"></div><div class="vir-item"></div><div class="vir-item"></div><div class="vir-item"></div><div class="vir-item"></div><div class="vir-item"></div><div class="vir-item"></div><div class="vir-item"></div><div class="vir-item"></div></div></div></section></div>', 1)
          , hs = [us];
        function _s(s, t, e, i, a, l) {
            return (0,
            n.wg)(),
            (0,
            n.iD)("div", vs, hs)
        }
        var gs = {
            name: "HomeFeaturedLoading"
        };
        const ws = (0,
        ls.Z)(gs, [["render", _s]]);
        var ps = ws
          , ys = {
            name: "HomeFeaturedApp",
            components: {
                HomeFeaturedList: ms,
                HomeFeaturedLoading: ps
            }
        };
        const fs = (0,
        ls.Z)(ys, [["render", l]]);
        var bs = fs;
        function ks(s, t, e, i, a, l) {
            const c = (0,
            n.up)("HomeResultList")
              , r = (0,
            n.up)("HomeResultLoading");
            return (0,
            n.wg)(),
            (0,
            n.j4)(n.n4, null, {
                default: (0,
                n.w5)((()=>[(0,
                n.Wm)(c)])),
                fallback: (0,
                n.w5)((()=>[(0,
                n.Wm)(r)])),
                _: 1
            })
        }
        const js = {
            class: "wide-container"
        }
          , Ds = {
            class: "wide-result-list",
            id: "result-list"
        }
          , Hs = {
            class: "swiper-container"
        }
          , zs = {
            class: "swiper-wrapper"
        }
          , xs = {
            class: "item-match-small"
        }
          , Zs = {
            class: "item-header"
        }
          , Ss = {
            class: "day"
        }
          , Ms = (0,
        n._)("div", {
            class: "status"
        }, "FT", -1)
          , Cs = {
            class: "item-body"
        }
          , Is = {
            class: "detail-match"
        }
          , Es = {
            class: "team-line is-home"
        }
          , Ls = {
            class: "team-name"
        }
          , Ps = {
            class: "team-logo"
        }
          , Ts = ["src"]
          , Ys = {
            class: "name"
        }
          , Fs = {
            class: "team-goal is-win"
        }
          , Ns = {
            class: "team-line"
        }
          , As = {
            class: "team-name"
        }
          , Ws = {
            class: "team-logo"
        }
          , Rs = ["src"]
          , Us = {
            class: "name"
        }
          , Bs = {
            class: "team-goal"
        }
          , Os = (0,
        n._)("div", {
            class: "clearfix"
        }, null, -1)
          , $s = (0,
        n.uE)('<div class="wide-navi"><div class="navi-next"><i class="icon-chevron-right"></i></div><div class="navi-prev"><i class="icon-chevron-left"></i></div></div>', 1);
        function qs(s, t, e, i, a, l) {
            return (0,
            n.wg)(),
            (0,
            n.iD)("div", js, [(0,
            n._)("div", Ds, [(0,
            n._)("div", Hs, [(0,
            n._)("div", zs, [((0,
            n.wg)(!0),
            (0,
            n.iD)(n.HY, null, (0,
            n.Ko)(i.matches, (s=>((0,
            n.wg)(),
            (0,
            n.iD)("div", {
                class: "swiper-slide",
                key: s.id
            }, [(0,
            n._)("div", xs, [(0,
            n._)("div", Zs, [(0,
            n._)("div", Ss, (0,
            M.zw)(s.start_date), 1), Ms]), (0,
            n._)("div", Cs, [(0,
            n._)("div", Is, [(0,
            n._)("div", Es, [(0,
            n._)("div", Ls, [(0,
            n._)("div", Ps, [(0,
            n._)("img", {
                loading: "lazy",
                src: s.home.logo
            }, null, 8, Ts)]), (0,
            n._)("h4", Ys, (0,
            M.zw)(s.home.name), 1)]), (0,
            n._)("div", Fs, (0,
            M.zw)(s.home_score), 1)]), (0,
            n._)("div", Ns, [(0,
            n._)("div", As, [(0,
            n._)("div", Ws, [(0,
            n._)("img", {
                loading: "lazy",
                src: s.away.logo
            }, null, 8, Rs)]), (0,
            n._)("h4", Us, (0,
            M.zw)(s.away.name), 1)]), (0,
            n._)("div", Bs, (0,
            M.zw)(s.away_score), 1)])])])])])))), 128))]), Os]), $s])])
        }
        var Ks = e(3390)
          , Vs = {
            name: "HomeResultList",
            async setup() {
                const s = S()
                  , t = (0,
                w.iH)([]);
                let e = null;
                const i = ()=>{
                    e = new Ks.ZP("#result-list .swiper-container",{
                        modules: [Ks.W_, Ks.tl, Ks.pt],
                        slidesPerView: 6,
                        spaceBetween: 30,
                        navigation: {
                            nextEl: ".wide-navi .navi-next",
                            prevEl: ".wide-navi .navi-prev"
                        },
                        breakpoints: {
                            320: {
                                slidesPerView: 2,
                                spaceBetween: 10
                            },
                            480: {
                                slidesPerView: 2,
                                spaceBetween: 10
                            },
                            640: {
                                slidesPerView: 3,
                                spaceBetween: 20
                            },
                            1060: {
                                slidesPerView: 6,
                                spaceBetween: 20
                            },
                            1600: {
                                slidesPerView: 8,
                                spaceBetween: 20
                            },
                            1921: {
                                slidesPerView: 8,
                                spaceBetween: 32
                            }
                        },
                        autoplay: {
                            delay: 2e3,
                            disableOnInteraction: !1
                        },
                        loop: !0
                    })
                }
                  , a = ()=>{
                    e && (e.destroy(),
                    e = null)
                }
                  , n = async()=>{
                    let e = await Z.fetchResult();
                    s.addData(e, {
                        source: "result"
                    }),
                    t.value = e
                }
                ;
                return await n(),
                {
                    stopSlide: a,
                    startSlide: i,
                    matches: t,
                    store: s
                }
            },
            mounted() {
                this.startSlide()
            },
            beforeUnmount() {
                this.stopSlide()
            }
        };
        const Js = (0,
        ls.Z)(Vs, [["render", qs]]);
        var Gs = Js;
        const Qs = {
            class: "ajax-loading is-load-result"
        }
          , Xs = (0,
        n.uE)('<div class="vir-item"></div><div class="vir-item"></div><div class="vir-item"></div><div class="vir-item"></div><div class="vir-item"></div><div class="vir-item"></div>', 6)
          , st = [Xs];
        function tt(s, t, e, i, a, l) {
            return (0,
            n.wg)(),
            (0,
            n.iD)("div", Qs, st)
        }
        var et = {
            name: "HomeResultLoading"
        };
        const it = (0,
        ls.Z)(et, [["render", tt]]);
        var at = it
          , nt = {
            name: "HomeResultApp",
            components: {
                HomeResultList: Gs,
                HomeResultLoading: at
            }
        };
        const lt = (0,
        ls.Z)(nt, [["render", ks]]);
        var ct = lt;
        const rt = {
            class: "sblock home-fixtures"
        }
          , ot = (0,
        n._)("div", {
            class: "sblock-header"
        }, [(0,
        n._)("div", {
            class: "sblock-header-title"
        }, [(0,
        n._)("h3", {
            class: "headingA1 l-title"
        }, "Fixtures List")])], -1)
          , dt = {
            class: "fix-time"
        }
          , mt = (0,
        n._)("div", null, "On Air", -1)
          , vt = {
            class: "fix-time-list"
        }
          , ut = ["onClick"]
          , ht = {
            class: "day"
        }
          , _t = {
            class: "month"
        }
          , gt = {
            class: "sblock-body"
        }
          , wt = {
            key: 0
        }
          , pt = {
            key: 0
        };
        function yt(s, t, e, a, l, c) {
            const r = (0,
            n.up)("HomeFixtureBody");
            return (0,
            n.wg)(),
            (0,
            n.iD)("section", rt, [ot, (0,
            n._)("div", dt, [c.is_show_live ? ((0,
            n.wg)(),
            (0,
            n.iD)("div", {
                key: 0,
                class: (0,
                M.C_)(["fix-time-live", {
                    active: "live" === a.active_date
                }]),
                onClick: t[0] || (t[0] = s=>c.changeDate("live"))
            }, [(0,
            n._)("span", null, (0,
            M.zw)(a.store.live_fixtures.length) + " LIVE", 1), mt], 2)) : (0,
            n.kq)("", !0), (0,
            n._)("div", vt, [((0,
            n.wg)(!0),
            (0,
            n.iD)(n.HY, null, (0,
            n.Ko)(a.dates, (s=>((0,
            n.wg)(),
            (0,
            n.iD)("div", {
                class: (0,
                M.C_)(["item", {
                    active: s.value === a.active_date
                }]),
                key: s.value,
                onClick: t=>c.changeDate(s.value)
            }, [(0,
            n._)("div", ht, (0,
            M.zw)(s.day), 1), (0,
            n._)("div", _t, (0,
            M.zw)(s.sub), 1)], 10, ut)))), 128))])]), (0,
            n._)("div", gt, [c.initTab("live") ? (0,
            n.wy)(((0,
            n.wg)(),
            (0,
            n.iD)("div", wt, [((0,
            n.wg)(),
            (0,
            n.j4)(r, {
                key: "live",
                date: "live"
            }))], 512)), [[i.F8, c.showTab("live")]]) : (0,
            n.kq)("", !0), ((0,
            n.wg)(!0),
            (0,
            n.iD)(n.HY, null, (0,
            n.Ko)(a.dates, (s=>((0,
            n.wg)(),
            (0,
            n.iD)("div", {
                key: s.value
            }, [c.initTab(s.value) ? (0,
            n.wy)(((0,
            n.wg)(),
            (0,
            n.iD)("div", pt, [(0,
            n.Wm)(r, {
                date: s.value
            }, null, 8, ["date"])], 512)), [[i.F8, c.showTab(s.value)]]) : (0,
            n.kq)("", !0)])))), 128))])])
        }
        function ft(s, t, e, i, a, l) {
            const c = (0,
            n.up)("HomeFixtureBodyDate")
              , r = (0,
            n.up)("HomeFixtureBodyLoading");
            return (0,
            n.wg)(),
            (0,
            n.j4)(n.n4, null, {
                default: (0,
                n.w5)((()=>[((0,
                n.wg)(),
                (0,
                n.j4)(c, {
                    key: e.date,
                    date: e.date
                }, null, 8, ["date"]))])),
                fallback: (0,
                n.w5)((()=>[(0,
                n.Wm)(r)])),
                _: 1
            })
        }
        const bt = {
            class: "fix-list"
        }
          , kt = (0,
        n.uE)('<div class="fix-list-league"><div class="ajax-loading is-load-league"><div class="vir-item"></div><div class="vir-item"></div><div class="vir-item"></div><div class="vir-item"></div><div class="vir-item"></div></div></div><div class="fix-list-match"><div class="ajax-loading is-load-fixtures"><div class="vir-item"></div><div class="vir-item"></div><div class="vir-item"></div><div class="vir-item"></div><div class="vir-item"></div><div class="vir-item"></div><div class="vir-item"></div><div class="vir-item"></div><div class="vir-item"></div><div class="vir-item"></div></div></div>', 2)
          , jt = [kt];
        function Dt(s, t, e, i, a, l) {
            return (0,
            n.wg)(),
            (0,
            n.iD)("div", bt, jt)
        }
        var Ht = {
            name: "HomeFixtureBodyLoading"
        };
        const zt = (0,
        ls.Z)(Ht, [["render", Dt]]);
        var xt = zt;
        const Zt = {
            class: "fix-list"
        }
          , St = {
            class: "fix-list-league"
        }
          , Mt = {
            class: "league-icon"
        }
          , Ct = ["src"]
          , It = (0,
        n._)("div", {
            class: "league-name"
        }, "All games", -1)
          , Et = ["onClick"]
          , Lt = {
            class: "league-icon"
        }
          , Pt = ["src"]
          , Tt = {
            class: "league-name"
        }
          , Yt = {
            class: "fix-list-match"
        }
          , Ft = {
            key: 0,
            class: "match-list match-list-default"
        }
          , Nt = {
            key: 1,
            class: "blank-more"
        }
          , At = (0,
        n._)("div", {
            class: "blank-more-text text-center p-5"
        }, [(0,
        n._)("div", null, "No match to display")], -1)
          , Wt = (0,
        n._)("div", {
            class: "d-flex justify-content-between"
        }, [(0,
        n._)("div", {
            class: "b-more-loading"
        }), (0,
        n._)("div", {
            class: "b-more-loading"
        })], -1)
          , Rt = [At, Wt];
        function Ut(s, t, e, i, a, l) {
            const c = (0,
            n.up)("HomeFixtureMatchItem");
            return (0,
            n.wg)(),
            (0,
            n.iD)("div", Zt, [(0,
            n._)("div", St, [l.matches && l.matches.length > 0 ? ((0,
            n.wg)(),
            (0,
            n.iD)("div", {
                key: 0,
                class: (0,
                M.C_)(["item-league-big", {
                    active: "all" === s.active_tournament
                }]),
                onClick: t[0] || (t[0] = ()=>{
                    this.active_tournament = "all"
                }
                )
            }, [(0,
            n._)("div", Mt, [(0,
            n._)("img", {
                src: s.assets_path("/images/thumbs/league-all.png")
            }, null, 8, Ct)]), It], 2)) : (0,
            n.kq)("", !0), ((0,
            n.wg)(!0),
            (0,
            n.iD)(n.HY, null, (0,
            n.Ko)(l.tournaments, (t=>((0,
            n.wg)(),
            (0,
            n.iD)("div", {
                key: t.model_id,
                class: (0,
                M.C_)(["item-league-big", {
                    active: s.active_tournament === t.model_id
                }]),
                onClick: ()=>{
                    this.active_tournament = t.model_id
                }
            }, [(0,
            n._)("div", Lt, [(0,
            n._)("img", {
                loading: "lazy",
                src: t.logo
            }, null, 8, Pt)]), (0,
            n._)("div", Tt, (0,
            M.zw)(t.name), 1)], 10, Et)))), 128))]), (0,
            n._)("div", Yt, [l.matches && l.matches.length > 0 ? ((0,
            n.wg)(),
            (0,
            n.iD)("div", Ft, [((0,
            n.wg)(!0),
            (0,
            n.iD)(n.HY, null, (0,
            n.Ko)(l.matches, (s=>((0,
            n.wg)(),
            (0,
            n.j4)(c, {
                key: s.id,
                "model-id": s.id
            }, null, 8, ["model-id"])))), 128))])) : ((0,
            n.wg)(),
            (0,
            n.iD)("div", Nt, Rt))])])
        }
        const Bt = {
            key: 0,
            class: "detail"
        }
          , Ot = {
            class: "time"
        }
          , $t = (0,
        n._)("div", {
            class: "live-stick mr-2"
        }, [(0,
        n._)("i", {
            class: "icon-s-circle mr-1"
        }), (0,
        n.Uk)("LIVE")], -1)
          , qt = {
            key: 0,
            class: "onair"
        }
          , Kt = {
            key: 0,
            class: "time"
        }
          , Vt = {
            class: "coming"
        }
          , Jt = {
            class: "league"
        }
          , Gt = {
            key: 1,
            class: "detail"
        }
          , Qt = {
            class: "time"
        }
          , Xt = {
            key: 0,
            class: "end"
        }
          , se = {
            key: 1,
            class: "coming"
        }
          , te = {
            class: "sub"
        }
          , ee = {
            class: "league"
        }
          , ie = {
            class: "teams"
        }
          , ae = {
            class: "team-logo"
        }
          , ne = ["src"]
          , le = {
            class: "team-name"
        }
          , ce = {
            class: "name"
        }
          , re = {
            class: "cards"
        }
          , oe = {
            class: "team-goal"
        }
          , de = {
            class: "team-logo"
        }
          , me = ["src"]
          , ve = {
            class: "team-name"
        }
          , ue = {
            class: "name"
        }
          , he = {
            class: "cards"
        }
          , _e = {
            class: "team-goal"
        };
        function ge(s, t, e, i, a, l) {
            const c = (0,
            n.up)("custom-link")
              , r = (0,
            n.up)("ItemExtraStatus");
            return l.item ? ((0,
            n.wg)(),
            (0,
            n.iD)("div", {
                key: 0,
                class: (0,
                M.C_)(["item-match item-football", {
                    "item-end": l.item.isEnd(),
                    "item-live": l.item.isLive()
                }])
            }, [(0,
            n.Wm)(c, {
                href: l.item.url,
                class: "match-link"
            }, null, 8, ["href"]), (0,
            n.Wm)(r, {
                status: l.item.match_status
            }, null, 8, ["status"]), l.item.isLive() ? ((0,
            n.wg)(),
            (0,
            n.iD)("div", Bt, [(0,
            n._)("div", Ot, [$t, 1 === l.item.match_status ? ((0,
            n.wg)(),
            (0,
            n.iD)("span", qt, (0,
            M.zw)(l.item.time_str), 1)) : (0,
            n.kq)("", !0)]), 1 !== l.item.match_status ? ((0,
            n.wg)(),
            (0,
            n.iD)("div", Kt, [(0,
            n._)("div", Vt, (0,
            M.zw)(l.item.start_time), 1)])) : (0,
            n.kq)("", !0), (0,
            n._)("div", Jt, (0,
            M.zw)(l.item.tournament.name), 1)])) : ((0,
            n.wg)(),
            (0,
            n.iD)("div", Gt, [(0,
            n._)("div", Qt, [l.item.isEnd() ? ((0,
            n.wg)(),
            (0,
            n.iD)("span", Xt, "FT")) : ((0,
            n.wg)(),
            (0,
            n.iD)("span", se, (0,
            M.zw)(l.item.start_time), 1))]), (0,
            n._)("div", te, (0,
            M.zw)(l.item.start_date), 1), (0,
            n._)("div", ee, (0,
            M.zw)(l.item.tournament.name), 1)])), (0,
            n._)("div", ie, [(0,
            n._)("div", {
                class: (0,
                M.C_)(["team-line is-home", {
                    "is-win": 1 === l.item.win_code
                }])
            }, [(0,
            n._)("div", ae, [(0,
            n._)("img", {
                loading: "lazy",
                src: l.item.home.logo
            }, null, 8, ne)]), (0,
            n._)("div", le, [(0,
            n._)("h4", ce, (0,
            M.zw)(l.item.home.name), 1), (0,
            n._)("div", re, [((0,
            n.wg)(!0),
            (0,
            n.iD)(n.HY, null, (0,
            n.Ko)(l.item.home_red_cards_arr, (s=>((0,
            n.wg)(),
            (0,
            n.iD)("div", {
                class: "red-card",
                key: s
            })))), 128))])]), (0,
            n._)("div", oe, (0,
            M.zw)(l.item.home_score), 1)], 2), (0,
            n._)("div", {
                class: (0,
                M.C_)(["team-line is-away", {
                    "is-win": 2 === l.item.win_code
                }])
            }, [(0,
            n._)("div", de, [(0,
            n._)("img", {
                loading: "lazy",
                src: l.item.away.logo
            }, null, 8, me)]), (0,
            n._)("div", ve, [(0,
            n._)("h4", ue, (0,
            M.zw)(l.item.away.name), 1), (0,
            n._)("div", he, [((0,
            n.wg)(!0),
            (0,
            n.iD)(n.HY, null, (0,
            n.Ko)(l.item.away_red_cards_arr, (s=>((0,
            n.wg)(),
            (0,
            n.iD)("div", {
                class: "red-card",
                key: s
            })))), 128))])]), (0,
            n._)("div", _e, (0,
            M.zw)(l.item.away_score), 1)], 2)])], 2)) : (0,
            n.kq)("", !0)
        }
        const we = (0,
        n._)("span", null, "This match", -1);
        function pe(s, t, e, i, a, l) {
            return l.is_show ? ((0,
            n.wg)(),
            (0,
            n.iD)("div", {
                key: 0,
                class: (0,
                M.C_)(["match-status", l.status_class])
            }, [(0,
            n._)("div", null, [we, (0,
            n.Uk)((0,
            M.zw)(l.status_str), 1)])], 2)) : (0,
            n.kq)("", !0)
        }
        var ye = {
            name: "ItemExtraStatus",
            props: ["status"],
            computed: {
                is_show() {
                    return "" !== this.status_class
                },
                status_class() {
                    switch (this.status) {
                    case k.DELAY:
                    case k.POSTPONED:
                        return "match-delay";
                    case k.INTERRUPTED:
                        return "match-lost";
                    case k.CANCELED:
                        return "match-cancel";
                    default:
                        return ""
                    }
                },
                status_str() {
                    switch (this.status) {
                    case k.DELAY:
                    case k.POSTPONED:
                        return "Postponed";
                    case k.INTERRUPTED:
                        return "Interrupted";
                    case k.CANCELED:
                        return "Canceled";
                    default:
                        return ""
                    }
                }
            }
        };
        const fe = (0,
        ls.Z)(ye, [["render", pe]]);
        var be = fe
          , ke = {
            name: "HomeFixtureMatchItem",
            props: ["modelId"],
            components: {
                ItemExtraStatus: be
            },
            setup() {
                const s = S();
                return {
                    store: s
                }
            },
            computed: {
                item() {
                    return this.store.db[this.modelId]
                }
            }
        };
        const je = (0,
        ls.Z)(ke, [["render", ge]]);
        var De = je;
        function He(s) {
            return window.assets_base_path + s
        }
        var ze = {
            name: "HomeFixtureBodyDate",
            props: ["date"],
            components: {
                HomeFixtureMatchItem: De
            },
            async setup(s) {
                const t = S();
                (0,
                a.Jk)(t),
                t.startSync();
                const e = (0,
                w.iH)("all");
                if ("live" === s.date) {
                    null === t.live_fixtures && await t.syncLive();
                    const {live_fixtures: s} = (0,
                    a.Jk)(t);
                    return {
                        fixtures: s,
                        active_tournament: e,
                        assets_path: He
                    }
                }
                {
                    const i = (0,
                    w.iH)([]);
                    let a = await Z.fetchFixture(s.date);
                    return t.addData(a, {
                        source: "fixture"
                    }),
                    a = p.filter(a, (function(t) {
                        return t && t.date === s.date
                    }
                    )),
                    i.value = a,
                    {
                        fixtures: i,
                        active_tournament: e,
                        assets_path: He
                    }
                }
            },
            computed: {
                tournaments() {
                    if (this.fixtures) {
                        let s = this.fixtures;
                        s = p.unionBy(s, (s=>s.tournament.model_id));
                        let t = [];
                        return s.map((s=>{
                            s.tournament && s.tournament.model_id && t.push(s.tournament)
                        }
                        )),
                        t = p.orderBy(t, ["is_featured", "priority"], ["desc", "desc"]),
                        t
                    }
                    return null
                },
                matches() {
                    let s = this.fixtures;
                    const t = this;
                    return "all" !== this.active_tournament && (s = p.filter(this.fixtures, (function(s) {
                        return s && s.tournament.model_id === t.active_tournament
                    }
                    ))),
                    s
                }
            },
            methods: {}
        };
        const xe = (0,
        ls.Z)(ze, [["render", Ut]]);
        var Ze = xe
          , Se = {
            name: "HomeFixtureBody",
            components: {
                HomeFixtureBodyLoading: xt,
                HomeFixtureBodyDate: Ze
            },
            props: ["date"]
        };
        const Me = (0,
        ls.Z)(Se, [["render", ft]]);
        var Ce = Me;
        const Ie = [];
        for (let gc = -1; gc < 7; gc++) {
            const s = b()().add(gc, "days");
            let t = s.format("DD");
            const e = s.format("YYYYMMDD")
              , i = s.format("dddd");
            0 === gc && (t = "Today"),
            Ie.push({
                day: t,
                sub: i,
                value: e,
                time: s
            })
        }
        var Ee = {
            name: "HomeFixtureApp",
            components: {
                HomeFixtureBody: Ce
            },
            setup() {
                const s = S();
                s.startSync();
                const t = (0,
                w.iH)(b()().format("YYYYMMDD"))
                  , e = (0,
                w.iH)("all")
                  , i = (0,
                w.iH)({
                    live: !1
                });
                return Ie.map((s=>{
                    i.value[s.value] = !1
                }
                )),
                i.value[b()().format("YYYYMMDD")] = !0,
                {
                    store: s,
                    tabs: i,
                    dates: Ie,
                    active_date: t,
                    active_tournament: e
                }
            },
            watch: {},
            computed: {
                is_show_live() {
                    return this.store.live_fixtures && this.store.live_fixtures.length
                },
                tournaments() {
                    return null
                },
                matches() {
                    return null
                }
            },
            methods: {
                showTab(s) {
                    const t = this.active_date === s;
                    return t
                },
                initTab(s) {
                    return !0 === this.tabs[s]
                },
                changeDate(s) {
                    this.tabs[s] || (this.tabs[s] = !0),
                    this.active_date = s
                }
            }
        };
        const Le = (0,
        ls.Z)(Ee, [["render", yt]]);
        var Pe = Le;
        const Te = ["href"];
        function Ye(s, t, e, i, a, l) {
            return (0,
            n.wg)(),
            (0,
            n.iD)("a", (0,
            n.dG)({
                href: s.$attrs.href
            }, s.$attrs), null, 16, Te)
        }
        var Fe = {
            name: "custom-link"
        };
        const Ne = (0,
        ls.Z)(Fe, [["render", Ye]]);
        var Ae = Ne;
        const We = {
            install(s) {
                s.component("custom-link", Ae)
            }
        };
        var Re = We;
        function Ue(s, t, e, i, a, l) {
            return (0,
            n.wg)(),
            (0,
            n.iD)("img", (0,
            M.vs)((0,
            n.F4)(s.$attrs)), null, 16)
        }
        var Be = {
            name: "custom-image"
        };
        const Oe = (0,
        ls.Z)(Be, [["render", Ue]]);
        var $e = Oe;
        const qe = {
            install(s) {
                s.component("custom-image", $e)
            }
        };
        var Ke = qe;
        const Ve = {
            class: "sblock home-standing"
        }
          , Je = (0,
        n._)("div", {
            class: "sblock-header"
        }, [(0,
        n._)("div", {
            class: "sblock-header-title"
        }, [(0,
        n._)("h3", {
            class: "headingA1 l-title"
        }, "Standing")])], -1)
          , Ge = {
            class: "sblock-body"
        }
          , Qe = {
            class: "stading-list"
        }
          , Xe = {
            class: "standing-league"
        }
          , si = {
            class: "sl-league nobd",
            "data-toggle": "dropdown",
            "aria-haspopup": "true",
            "aria-expanded": "false"
        }
          , ti = {
            class: "league-icon"
        }
          , ei = {
            class: "league-name"
        }
          , ii = (0,
        n._)("div", {
            class: "league-arrow"
        }, [(0,
        n._)("i", {
            class: "icon-chevron-down"
        })], -1)
          , ai = {
            class: "dropdown-menu s-dropdown-menu dropdown-menu-league"
        }
          , ni = ["onClick"]
          , li = {
            class: "item-league"
        }
          , ci = {
            class: "league-icon"
        }
          , ri = {
            key: 0
        };
        function oi(s, t, e, a, l, c) {
            const r = (0,
            n.up)("custom-image")
              , o = (0,
            n.up)("HomeTournamentStandingWrapper");
            return (0,
            n.wg)(),
            (0,
            n.iD)("section", Ve, [Je, (0,
            n._)("div", Ge, [(0,
            n._)("div", Qe, [(0,
            n._)("div", Xe, [(0,
            n._)("div", si, [(0,
            n._)("div", ti, [(0,
            n.Wm)(r, {
                src: a.selected_tournament.logo
            }, null, 8, ["src"])]), (0,
            n._)("div", ei, (0,
            M.zw)(a.selected_tournament.name), 1), ii]), (0,
            n._)("div", ai, [((0,
            n.wg)(!0),
            (0,
            n.iD)(n.HY, null, (0,
            n.Ko)(a.tournaments, (s=>((0,
            n.wg)(),
            (0,
            n.iD)("a", {
                href: "javascript:void(0)",
                onClick: t=>c.change(s),
                class: (0,
                M.C_)(["dropdown-item", {
                    active: s.model_id === a.selected_tournament.model_id
                }]),
                key: s.model_id
            }, [(0,
            n._)("div", li, [(0,
            n._)("i", ci, [(0,
            n.Wm)(r, {
                src: s.logo
            }, null, 8, ["src"])]), (0,
            n._)("span", null, (0,
            M.zw)(s.name), 1)])], 10, ni)))), 128))]), ((0,
            n.wg)(!0),
            (0,
            n.iD)(n.HY, null, (0,
            n.Ko)(a.tournaments, (s=>((0,
            n.wg)(),
            (0,
            n.iD)("div", {
                key: s.model_id
            }, [c.initTab(s) ? (0,
            n.wy)(((0,
            n.wg)(),
            (0,
            n.iD)("div", ri, [(0,
            n.Wm)(o, {
                "model-id": s.model_id
            }, null, 8, ["model-id"])], 512)), [[i.F8, c.showTab(s)]]) : (0,
            n.kq)("", !0)])))), 128))])])])])
        }
        function di(s, t, e, i, a, l) {
            const c = (0,
            n.up)("HomeTournamentStanding")
              , r = (0,
            n.up)("HomeTournamentStandingLoading");
            return (0,
            n.wg)(),
            (0,
            n.j4)(n.n4, null, {
                default: (0,
                n.w5)((()=>[(0,
                n.Wm)(c, (0,
                M.vs)((0,
                n.F4)(s.$props)), null, 16)])),
                fallback: (0,
                n.w5)((()=>[(0,
                n.Wm)(r)])),
                _: 1
            })
        }
        const mi = {
            key: 0
        }
          , vi = {
            key: 1
        };
        function ui(s, t, e, i, a, l) {
            const c = (0,
            n.up)("SingleStanding")
              , r = (0,
            n.up)("MultipleStanding")
              , o = (0,
            n.up)("HomeTournamentStandingLoading");
            return i.standings && i.standings.length > 0 ? ((0,
            n.wg)(),
            (0,
            n.iD)("div", mi, [1 === i.standings.length ? ((0,
            n.wg)(),
            (0,
            n.j4)(c, {
                key: 0,
                standings: i.standings
            }, null, 8, ["standings"])) : ((0,
            n.wg)(),
            (0,
            n.j4)(r, {
                key: 1,
                standings: i.standings
            }, null, 8, ["standings"]))])) : ((0,
            n.wg)(),
            (0,
            n.iD)("div", vi, [(0,
            n.Wm)(o)]))
        }
        class hi {
            constructor(s) {
                (0,
                y.Z)(this, "team", void 0),
                (0,
                y.Z)(this, "points", void 0),
                (0,
                y.Z)(this, "position", void 0),
                (0,
                y.Z)(this, "deduct_points", void 0),
                (0,
                y.Z)(this, "total", void 0),
                (0,
                y.Z)(this, "won", void 0),
                (0,
                y.Z)(this, "draw", void 0),
                (0,
                y.Z)(this, "loss", void 0),
                (0,
                y.Z)(this, "goals", void 0),
                (0,
                y.Z)(this, "goals_against", void 0),
                Object.assign(this, s)
            }
        }
        class _i {
            constructor(s) {
                (0,
                y.Z)(this, "tournament", void 0),
                (0,
                y.Z)(this, "rows", void 0),
                (0,
                y.Z)(this, "conference", void 0),
                (0,
                y.Z)(this, "stage_id", void 0),
                (0,
                y.Z)(this, "group", void 0);
                let t = s.rows;
                delete s.rows,
                Object.assign(this, s),
                t && (t = t.map((s=>new hi(s))),
                this.rows = t)
            }
        }
        class gi {
            static async fetchStandings(s) {
                try {
                    const t = await x.get(`/v1/tournament/standing/${s}`);
                    return t.data.data.map((s=>new _i(s)))
                } catch (t) {
                    console.error(t)
                }
            }
        }
        const wi = {
            class: "ajax-loading is-load-stand"
        }
          , pi = (0,
        n.uE)('<div class="vir-item"></div><div class="vir-item"></div><div class="vir-item"></div><div class="vir-item"></div><div class="vir-item"></div><div class="vir-item"></div><div class="vir-item"></div><div class="vir-item"></div><div class="vir-item"></div><div class="vir-item"></div><div class="vir-item"></div><div class="vir-item"></div><div class="vir-item"></div><div class="vir-item"></div><div class="vir-item"></div><div class="vir-item"></div><div class="vir-item"></div><div class="vir-item"></div><div class="vir-item"></div><div class="vir-item"></div>', 20)
          , yi = [pi];
        function fi(s, t, e, i, a, l) {
            return (0,
            n.wg)(),
            (0,
            n.iD)("div", wi, yi)
        }
        var bi = {
            name: "HomeTournamentStandingLoading"
        };
        const ki = (0,
        ls.Z)(bi, [["render", fi]]);
        var ji = ki;
        const Di = {
            class: "slt-display"
        }
          , Hi = (0,
        n.uE)('<div class="slt-row slt-header"><div class="stats stats-number"></div><div class="team"></div><div class="stats stats-p">P</div><div class="stats stats-pts">Pts</div><div class="stats stats-w">W</div><div class="stats stats-d">D</div><div class="stats stats-l">L</div><div class="stats stats-gd">GD</div></div>', 1)
          , zi = {
            class: "stats stats-number"
        }
          , xi = {
            class: "team"
        }
          , Zi = {
            class: "team-line"
        }
          , Si = {
            class: "team-logo"
        }
          , Mi = {
            class: "team-name"
        }
          , Ci = {
            class: "stats stats-p"
        }
          , Ii = {
            class: "stats stats-pts"
        }
          , Ei = {
            class: "stats stats-w"
        }
          , Li = {
            class: "stats stats-d"
        }
          , Pi = {
            class: "stats stats-l"
        }
          , Ti = {
            class: "stats stats-gd"
        }
          , Yi = {
            class: "block-more"
        }
          , Fi = (0,
        n._)("i", {
            class: "icon-caret-down icon-16 mr-2"
        }, null, -1);
        function Ni(s, t, e, i, a, l) {
            const c = (0,
            n.up)("custom-image");
            return (0,
            n.wg)(),
            (0,
            n.iD)(n.HY, null, [(0,
            n._)("div", {
                class: (0,
                M.C_)(["standing-group", {
                    "is-collapse": !i.is_full
                }])
            }, [((0,
            n.wg)(!0),
            (0,
            n.iD)(n.HY, null, (0,
            n.Ko)(e.standings, (s=>((0,
            n.wg)(),
            (0,
            n.iD)("div", {
                class: "sl-table",
                key: s
            }, [(0,
            n._)("div", Di, "Group " + (0,
            M.zw)(s.group), 1), Hi, ((0,
            n.wg)(!0),
            (0,
            n.iD)(n.HY, null, (0,
            n.Ko)(s.rows, (s=>((0,
            n.wg)(),
            (0,
            n.iD)("div", {
                class: "slt-row slt-td",
                key: s
            }, [(0,
            n._)("div", zi, [(0,
            n._)("span", {
                class: (0,
                M.C_)({
                    "on-champion": s.position <= 2
                })
            }, (0,
            M.zw)(s.position), 3)]), (0,
            n._)("div", xi, [(0,
            n._)("div", Zi, [(0,
            n._)("div", Si, [(0,
            n.Wm)(c, {
                src: s.team.logo
            }, null, 8, ["src"])]), (0,
            n._)("div", Mi, (0,
            M.zw)(s.team.name), 1)])]), (0,
            n._)("div", Ci, (0,
            M.zw)(s.total), 1), (0,
            n._)("div", Ii, (0,
            M.zw)(s.points), 1), (0,
            n._)("div", Ei, (0,
            M.zw)(s.won), 1), (0,
            n._)("div", Li, (0,
            M.zw)(s.draw), 1), (0,
            n._)("div", Pi, (0,
            M.zw)(s.loss), 1), (0,
            n._)("div", Ti, (0,
            M.zw)(s.goals - s.goals_against), 1)])))), 128))])))), 128))], 2), (0,
            n._)("div", Yi, [(0,
            n._)("a", {
                onClick: t[0] || (t[0] = (...s)=>i.toggleShowFull && i.toggleShowFull(...s)),
                href: "javascript:void(0)",
                class: (0,
                M.C_)(["btn btn-sm btn-block btn-more", {
                    active: i.is_full
                }])
            }, [Fi, i.is_full ? ((0,
            n.wg)(),
            (0,
            n.iD)(n.HY, {
                key: 1
            }, [(0,
            n.Uk)("View less")], 64)) : ((0,
            n.wg)(),
            (0,
            n.iD)(n.HY, {
                key: 0
            }, [(0,
            n.Uk)("View more")], 64))], 2)])], 64)
        }
        var Ai = {
            name: "MultipleStanding",
            props: ["standings"],
            setup() {
                const s = (0,
                w.iH)(!1)
                  , t = ()=>{
                    s.value = !s.value
                }
                ;
                return {
                    is_full: s,
                    toggleShowFull: t
                }
            }
        };
        const Wi = (0,
        ls.Z)(Ai, [["render", Ni]]);
        var Ri = Wi;
        const Ui = {
            class: "sl-table"
        }
          , Bi = (0,
        n.uE)('<div class="slt-row slt-header"><div class="stats stats-number"></div><div class="team"></div><div class="stats stats-p">P</div><div class="stats stats-pts">Pts</div><div class="stats stats-w">W</div><div class="stats stats-d">D</div><div class="stats stats-l">L</div><div class="stats stats-gd">GD</div></div>', 1)
          , Oi = {
            class: "stats stats-number"
        }
          , $i = {
            class: "team"
        }
          , qi = {
            class: "team-line"
        }
          , Ki = {
            class: "team-logo"
        }
          , Vi = {
            class: "team-name"
        }
          , Ji = {
            class: "stats stats-p"
        }
          , Gi = {
            class: "stats stats-pts"
        }
          , Qi = {
            class: "stats stats-w"
        }
          , Xi = {
            class: "stats stats-d"
        }
          , sa = {
            class: "stats stats-l"
        }
          , ta = {
            class: "stats stats-gd"
        };
        function ea(s, t, e, i, a, l) {
            const c = (0,
            n.up)("custom-image");
            return (0,
            n.wg)(),
            (0,
            n.iD)("div", Ui, [Bi, ((0,
            n.wg)(!0),
            (0,
            n.iD)(n.HY, null, (0,
            n.Ko)(i.standing.rows, (s=>((0,
            n.wg)(),
            (0,
            n.iD)("div", {
                class: "slt-row slt-td",
                key: s
            }, [(0,
            n._)("div", Oi, [(0,
            n._)("span", {
                class: (0,
                M.C_)({
                    "on-champion": s.position <= 4
                })
            }, (0,
            M.zw)(s.position), 3)]), (0,
            n._)("div", $i, [(0,
            n._)("div", qi, [(0,
            n._)("div", Ki, [(0,
            n.Wm)(c, {
                src: s.team.logo
            }, null, 8, ["src"])]), (0,
            n._)("div", Vi, (0,
            M.zw)(s.team.name), 1)])]), (0,
            n._)("div", Ji, (0,
            M.zw)(s.total), 1), (0,
            n._)("div", Gi, (0,
            M.zw)(s.points), 1), (0,
            n._)("div", Qi, (0,
            M.zw)(s.won), 1), (0,
            n._)("div", Xi, (0,
            M.zw)(s.draw), 1), (0,
            n._)("div", sa, (0,
            M.zw)(s.loss), 1), (0,
            n._)("div", ta, (0,
            M.zw)(s.goals - s.goals_against), 1)])))), 128))])
        }
        var ia = {
            name: "SingleStanding",
            props: ["standings"],
            setup(s) {
                const {standings: t} = (0,
                w.BK)(s)
                  , e = (0,
                w.iH)(null);
                return t && Array.isArray(t.value) && t.value.length > 0 && (e.value = t.value[0]),
                {
                    standing: e
                }
            }
        };
        const aa = (0,
        ls.Z)(ia, [["render", ea]]);
        var na = aa
          , la = {
            name: "HomeTournamentStanding",
            components: {
                HomeTournamentStandingLoading: ji,
                MultipleStanding: Ri,
                SingleStanding: na
            },
            props: ["modelId"],
            async setup(s) {
                const t = await gi.fetchStandings(s.modelId)
                  , e = (0,
                w.iH)(0);
                return {
                    active_index: e,
                    standings: t
                }
            }
        };
        const ca = (0,
        ls.Z)(la, [["render", ui]]);
        var ra = ca
          , oa = {
            name: "HomeTournamentStandingWrapper",
            components: {
                HomeTournamentStanding: ra,
                HomeTournamentStandingLoading: ji
            },
            props: ["modelId"]
        };
        const da = (0,
        ls.Z)(oa, [["render", di]]);
        var ma = da
          , va = {
            name: "HomeStandingApp",
            components: {
                HomeTournamentStandingWrapper: ma
            },
            setup() {
                const s = window.tournament_standings
                  , t = (0,
                w.iH)(s[0])
                  , e = (0,
                w.iH)({});
                return s.map(((s,t)=>{
                    e.value[s.model_id] = 0 === t
                }
                )),
                {
                    tabs: e,
                    tournaments: s,
                    selected_tournament: t
                }
            },
            methods: {
                showTab(s) {
                    return this.selected_tournament.model_id === s.model_id
                },
                initTab(s) {
                    return !0 === this.tabs[s.model_id]
                },
                change(s) {
                    this.tabs[s.model_id] || (this.tabs[s.model_id] = !0),
                    this.selected_tournament = s
                }
            }
        };
        const ua = (0,
        ls.Z)(va, [["render", oi]]);
        var ha = ua;
        function _a(s, t, e, i, a, l) {
            const c = (0,
            n.up)("DetailRelatedList")
              , r = (0,
            n.up)("DetailRelatedLoading");
            return (0,
            n.wg)(),
            (0,
            n.j4)(n.n4, null, {
                default: (0,
                n.w5)((()=>[(0,
                n.Wm)(c)])),
                fallback: (0,
                n.w5)((()=>[(0,
                n.Wm)(r)])),
                _: 1
            })
        }
        const ga = {
            class: "section-wrap is-focus"
        }
          , wa = {
            class: "container"
        }
          , pa = {
            class: "sblock home-upcoming"
        }
          , ya = (0,
        n._)("div", {
            class: "sblock-header"
        }, [(0,
        n._)("div", {
            class: "sblock-header-title"
        }, [(0,
        n._)("h3", {
            class: "headingA1 l-title"
        }, "Hot Match")])], -1)
          , fa = {
            class: "sblock-body"
        }
          , ba = {
            class: "match-list match-grid large-match-grid"
        };
        function ka(s, t, e, i, a, l) {
            const c = (0,
            n.up)("MatchFeaturedItem");
            return (0,
            n.wg)(),
            (0,
            n.iD)("div", ga, [(0,
            n._)("div", wa, [(0,
            n._)("section", pa, [ya, (0,
            n._)("div", fa, [(0,
            n._)("div", ba, [((0,
            n.wg)(!0),
            (0,
            n.iD)(n.HY, null, (0,
            n.Ko)(i.matches, (s=>((0,
            n.wg)(),
            (0,
            n.j4)(c, {
                key: s.id,
                "model-id": s.id
            }, null, 8, ["model-id"])))), 128))])])])])])
        }
        const ja = (0,
        a.Q_)("detail", (()=>{
            let s = window.show_chat || !1;
            const t = (0,
            w.iH)(s)
              , e = (0,
            w.iH)(null);
            function i(s) {
                e.value = s
            }
            function a() {
                e.value = null,
                t.value = !1
            }
            return e.value = window.detail_match_id,
            {
                match_id: e,
                viewMatch: i,
                is_show_chat: t,
                reset: a
            }
        }
        ));
        var Da = {
            name: "DetailRelatedList",
            components: {
                MatchFeaturedItem: rs
            },
            async setup() {
                const s = S()
                  , t = ja()
                  , {match_id: e} = (0,
                a.Jk)(t)
                  , i = (0,
                w.iH)([])
                  , n = async()=>{
                    let t = await Z.fetchRelated(e.value);
                    s.addData(t, {
                        source: "related"
                    }),
                    i.value = t
                }
                ;
                return await n(),
                setInterval((function() {
                    n()
                }
                ), 3e5),
                {
                    matches: i,
                    store: s
                }
            }
        };
        const Ha = (0,
        ls.Z)(Da, [["render", ka]]);
        var za = Ha;
        const xa = {
            class: "section-wrap is-focus"
        }
          , Za = (0,
        n.uE)('<div class="container"><section class="sblock home-upcoming"><div class="sblock-header"><div class="sblock-header-title"><h3 class="headingA1 l-title">Hot Match</h3></div></div><div class="sblock-body"><div class="ajax-loading is-load-focus"><div class="vir-item"></div><div class="vir-item"></div><div class="vir-item"></div><div class="vir-item"></div><div class="vir-item"></div><div class="vir-item"></div><div class="vir-item"></div><div class="vir-item"></div><div class="vir-item"></div><div class="vir-item"></div></div></div></section></div>', 1)
          , Sa = [Za];
        function Ma(s, t, e, i, a, l) {
            return (0,
            n.wg)(),
            (0,
            n.iD)("div", xa, Sa)
        }
        var Ca = {
            name: "DetailRelatedLoading"
        };
        const Ia = (0,
        ls.Z)(Ca, [["render", Ma]]);
        var Ea = Ia
          , La = {
            name: "DetailRelatedApp",
            components: {
                DetailRelatedList: za,
                DetailRelatedLoading: Ea
            }
        };
        const Pa = (0,
        ls.Z)(La, [["render", _a]]);
        var Ta = Pa;
        function Ya(s, t, e, i, a, l) {
            const c = (0,
            n.up)("MatchDetail")
              , r = (0,
            n.up)("MatchDetailLoading");
            return (0,
            n.wg)(),
            (0,
            n.j4)(n.n4, null, {
                default: (0,
                n.w5)((()=>[(0,
                n.Wm)(c)])),
                fallback: (0,
                n.w5)((()=>[(0,
                n.Wm)(r)])),
                _: 1
            })
        }
        const Fa = {
            class: "match-wrap"
        }
          , Na = {
            class: "container"
        }
          , Aa = {
            class: "match-section"
        }
          , Wa = {
            class: "ms-detail"
        }
          , Ra = {
            class: "msd-title"
        }
          , Ua = {
            class: "headlineA4 match-title"
        }
          , Ba = (0,
        n._)("span", null, "vs", -1)
          , Oa = {
            class: "msd-teams"
        }
          , $a = {
            class: "team-line is-home",
            style: {
                "background-color": "#a41313"
            }
        }
          , qa = {
            class: "team-logo"
        }
          , Ka = ["src"]
          , Va = {
            class: "team-goal"
        }
          , Ja = {
            class: "team-line is-away",
            style: {
                "background-color": "#222297"
            }
        }
          , Ga = {
            class: "team-logo"
        }
          , Qa = ["src"]
          , Xa = {
            class: "team-goal"
        }
          , sn = {
            class: "msd-info"
        }
          , tn = {
            class: "league-detail"
        }
          , en = {
            key: 0,
            class: "time"
        }
          , an = {
            class: "status"
        }
          , nn = (0,
        n._)("div", {
            class: "time-icon"
        }, [(0,
        n._)("i", {
            class: "icon-run"
        })], -1)
          , ln = {
            class: "league-flex"
        }
          , cn = {
            class: "league-icon invert-icon"
        }
          , rn = ["src"]
          , on = {
            class: "league-name"
        }
          , dn = (0,
        n._)("i", {
            class: "icon-calendar"
        }, null, -1)
          , mn = (0,
        n._)("i", {
            class: "icon-s-location-plus"
        }, null, -1)
          , vn = {
            class: "ms-media"
        }
          , un = {
            class: "media-side"
        }
          , hn = {
            class: "match-side-head"
        }
          , _n = {
            class: "match-title"
        }
          , gn = (0,
        n._)("div", {
            class: "match-social"
        }, [(0,
        n._)("div", {
            class: "title"
        }, "Share this"), (0,
        n._)("div", {
            class: "addthis_inline_share_toolbox"
        })], -1);
        function wn(s, t, e, i, a, l) {
            const c = (0,
            n.up)("MatchMiniCountDown")
              , r = (0,
            n.up)("MatchStats")
              , o = (0,
            n.up)("MatchPlayer")
              , d = (0,
            n.up)("MatchChatBox");
            return (0,
            n.wg)(),
            (0,
            n.iD)("div", Fa, [(0,
            n._)("div", Na, [(0,
            n._)("section", Aa, [(0,
            n._)("div", Wa, [(0,
            n._)("div", Ra, [(0,
            n._)("h2", Ua, [(0,
            n.Uk)((0,
            M.zw)(l.item.home.name) + " ", 1), Ba, (0,
            n.Uk)(" " + (0,
            M.zw)(l.item.away.name), 1)])]), (0,
            n._)("div", Oa, [(0,
            n._)("div", $a, [(0,
            n._)("div", qa, [(0,
            n._)("img", {
                loading: "lazy",
                src: l.item.home.logo
            }, null, 8, Ka)]), (0,
            n._)("div", Va, [(0,
            n._)("span", null, (0,
            M.zw)(l.item.home_score), 1)])]), (0,
            n._)("div", Ja, [(0,
            n._)("div", Ga, [(0,
            n._)("img", {
                loading: "lazy",
                src: l.item.away.logo
            }, null, 8, Qa)]), (0,
            n._)("div", Xa, [(0,
            n._)("span", null, (0,
            M.zw)(l.item.away_score), 1)])])]), (0,
            n._)("div", sn, [2 === l.item.match_status ? ((0,
            n.wg)(),
            (0,
            n.j4)(c, {
                key: 0,
                timestamp: l.item.timestamp
            }, null, 8, ["timestamp"])) : ((0,
            n.wg)(),
            (0,
            n.j4)(r, {
                key: 1
            })), (0,
            n._)("div", tn, [l.item.time_str ? ((0,
            n.wg)(),
            (0,
            n.iD)("div", en, [(0,
            n._)("div", an, (0,
            M.zw)(l.item.time_str), 1), nn])) : (0,
            n.kq)("", !0), (0,
            n._)("div", ln, [(0,
            n._)("div", cn, [(0,
            n._)("img", {
                loading: "lazy",
                src: l.item.tournament.logo
            }, null, 8, rn)]), (0,
            n._)("div", on, (0,
            M.zw)(l.item.tournament.name), 1)]), (0,
            n._)("div", null, [dn, (0,
            n._)("span", null, (0,
            M.zw)(l.item.formatTime("HH:mm DD/MM/YYYY (Z)")), 1)]), (0,
            n._)("div", null, [mn, (0,
            n._)("span", null, (0,
            M.zw)(l.item.venue_name), 1)])])])]), (0,
            n._)("div", vn, [(0,
            n._)("div", un, [(0,
            n._)("div", hn, [(0,
            n._)("h2", _n, (0,
            M.zw)(i.seo.h1), 1)]), gn]), (0,
            n.Wm)(o)]), (0,
            n.Wm)(d)])])])
        }
        const pn = {
            class: "ms-chat"
        }
          , yn = {
            class: "live-chat"
        }
          , fn = {
            class: "ls___-chatbox"
        }
          , bn = ["src"]
          , kn = {
            class: "chat_off-content"
        }
          , jn = (0,
        n._)("div", {
            class: "text"
        }, "Chat is off", -1);
        function Dn(s, t, e, i, a, l) {
            return (0,
            n.wg)(),
            (0,
            n.iD)("div", pn, [(0,
            n._)("div", yn, [(0,
            n._)("div", fn, [(0,
            n._)("div", {
                class: (0,
                M.C_)(["chatbox_wrap", {
                    "chat-show": i.is_show_chat,
                    "chat-hide": !i.is_show_chat
                }])
            }, [i.is_created ? ((0,
            n.wg)(),
            (0,
            n.iD)("iframe", {
                key: 0,
                src: l.chat_url,
                width: "100%",
                height: "100%",
                allowtransparency: "yes",
                allow: "autoplay",
                frameborder: "0",
                marginheight: "0",
                marginwidth: "0",
                scrolling: "auto"
            }, null, 8, bn)) : (0,
            n.kq)("", !0)], 2), (0,
            n._)("div", {
                id: "chat_off",
                class: (0,
                M.C_)({
                    "chat-show": !i.is_show_chat,
                    "chat-hide": i.is_show_chat
                })
            }, [(0,
            n._)("div", kn, [jn, (0,
            n._)("div", {
                id: "chat_on",
                class: "sbtn sbtn-sm sbtn-secondary",
                onClick: t[0] || (t[0] = s=>l.show())
            }, "Show chat")])], 2)])])])
        }
        var Hn = {
            name: "MatchChatBox",
            expose: ["show", "hide", "getStatus"],
            props: ["url"],
            setup(s) {
                const t = ja()
                  , e = (0,
                w.iH)(!1)
                  , {is_show_chat: i} = (0,
                a.Jk)(t);
                return !0 === i.value && (e.value = !0),
                {
                    is_show_chat: i,
                    is_created: e
                }
            },
            computed: {
                chat_url() {
                    return this.url ? this.url : window.chat_url
                }
            },
            methods: {
                getStatus() {
                    return this.is_show_chat
                },
                show() {
                    this.is_show_chat = !0,
                    this.is_created || (this.is_created = !0)
                },
                hide() {
                    this.is_show_chat = !1
                }
            },
            beforeUnmount() {
                this.is_show_chat = !1
            }
        };
        const zn = (0,
        ls.Z)(Hn, [["render", Dn]]);
        var xn = zn;
        const Zn = {
            class: "media-frame"
        }
          , Sn = {
            id: "jw-container",
            style: {
                position: "absolute !important"
            }
        }
          , Mn = {
            class: "box-countdown"
        };
        function Cn(s, t, e, a, l, c) {
            const r = (0,
            n.up)("MatchPlayerCountDown")
              , o = (0,
            n.up)("PlayerToolbarApp");
            return (0,
            n.wg)(),
            (0,
            n.iD)(n.HY, null, [(0,
            n._)("div", Zn, [(0,
            n.wy)((0,
            n._)("div", Sn, null, 512), [[i.F8, a.player_created]]), (0,
            n.wy)((0,
            n._)("div", Mn, [(0,
            n.Wm)(r, {
                timestamp: c.item.timestamp
            }, null, 8, ["timestamp"])], 512), [[i.F8, !a.player_created]])]), (0,
            n.Wm)(o, {
                onPlay: c.handlePlay
            }, null, 8, ["onPlay"])], 64)
        }
        const In = {
            class: "media-side"
        }
          , En = {
            class: "match-extend"
        }
          , Ln = (0,
        n._)("i", {
            class: "icon-expand mr-2"
        }, null, -1)
          , Pn = (0,
        n._)("i", {
            class: "icon-s-comment-x mr-2"
        }, null, -1);
        function Tn(s, t, e, i, a, l) {
            const c = (0,
            n.up)("PlayerToolbar")
              , r = (0,
            n.up)("PlayerToolbarLoading");
            return (0,
            n.wg)(),
            (0,
            n.iD)("div", In, [((0,
            n.wg)(),
            (0,
            n.j4)(n.n4, null, {
                default: (0,
                n.w5)((()=>[(0,
                n.Wm)(c, {
                    onPlay: l.play
                }, null, 8, ["onPlay"])])),
                fallback: (0,
                n.w5)((()=>[(0,
                n.Wm)(r)])),
                _: 1
            })), (0,
            n._)("div", En, [(0,
            n._)("div", {
                onClick: t[0] || (t[0] = (...s)=>l.toggleFullscreen && l.toggleFullscreen(...s)),
                class: (0,
                M.C_)([{
                    active: i.is_fullscreen_mode
                }, "sbtn sbtn-secondary"]),
                id: "match-extend-btn"
            }, [Ln, (0,
            n.Uk)("Extend")], 2), (0,
            n._)("div", {
                id: "chat-toggle",
                class: (0,
                M.C_)([{
                    active: !i.is_show_chat
                }, "sbtn sbtn-secondary"]),
                onClick: t[1] || (t[1] = (...s)=>l.toggleChat && l.toggleChat(...s))
            }, [Pn, (0,
            n.Uk)("Hide chat")], 2)])])
        }
        const Yn = {
            class: "server-wrap"
        }
          , Fn = (0,
        n._)("div", {
            class: "title"
        }, "Server Play", -1)
          , Nn = {
            class: "server-list"
        }
          , An = ["onClick"]
          , Wn = (0,
        n._)("i", {
            class: "icon-play mr-1"
        }, null, -1)
          , Rn = {
            class: "server-mobile"
        }
          , Un = (0,
        n._)("div", {
            class: "sbtn sbtn-sm sbtn-primary",
            "data-toggle": "dropdown",
            "aria-haspopup": "true",
            "aria-expanded": "false"
        }, [(0,
        n._)("i", {
            class: "icon-server mr-2"
        }), (0,
        n.Uk)("Server Play"), (0,
        n._)("i", {
            class: "icon-chevron-down ml-2"
        })], -1)
          , Bn = {
            class: "dropdown-menu s-dropdown-menu"
        }
          , On = ["onClick"]
          , $n = (0,
        n._)("i", {
            class: "icon-play mr-2"
        }, null, -1)
          , qn = (0,
        n._)("div", {
            class: "server-wrap"
        }, null, -1)
          , Kn = (0,
        n._)("div", {
            class: "server-mobile"
        }, null, -1);
        function Vn(s, t, e, i, a, l) {
            return i.play_urls && i.play_urls.length > 0 ? ((0,
            n.wg)(),
            (0,
            n.iD)(n.HY, {
                key: 0
            }, [(0,
            n._)("div", Yn, [Fn, (0,
            n._)("div", Nn, [((0,
            n.wg)(!0),
            (0,
            n.iD)(n.HY, null, (0,
            n.Ko)(i.play_urls, ((s,t)=>((0,
            n.wg)(),
            (0,
            n.iD)("div", {
                class: "item",
                key: s
            }, [(0,
            n._)("a", {
                onClick: e=>i.play(s, t),
                href: "javascript:void(0)",
                class: (0,
                M.C_)(["sbtn sbtn-sm sbtn-secondary", {
                    active: t === i.active_index
                }])
            }, [Wn, (0,
            n.Uk)((0,
            M.zw)(s.name), 1)], 10, An)])))), 128))])]), (0,
            n._)("div", Rn, [Un, (0,
            n._)("div", Bn, [((0,
            n.wg)(!0),
            (0,
            n.iD)(n.HY, null, (0,
            n.Ko)(i.play_urls, ((s,t)=>((0,
            n.wg)(),
            (0,
            n.iD)("a", {
                class: (0,
                M.C_)(["dropdown-item", {
                    active: t === i.active_index
                }]),
                href: "javascript:void(0)",
                key: s,
                onClick: e=>i.play(s, t)
            }, [$n, (0,
            n.Uk)((0,
            M.zw)(s.name), 1)], 10, On)))), 128))])])], 64)) : ((0,
            n.wg)(),
            (0,
            n.iD)(n.HY, {
                key: 1
            }, [qn, Kn], 64))
        }
        var Jn = {
            name: "MatchPlayerToolbar",
            async setup(s, {emit: t}) {
                const e = S()
                  , i = ja()
                  , {match_id: n} = (0,
                a.Jk)(i)
                  , l = (0,
                w.iH)([])
                  , c = (0,
                w.iH)(null)
                  , r = (s,e,i=!0)=>{
                    if (i) {
                        const s = new URL(location.href);
                        s.searchParams.delete("link"),
                        0 !== e && s.searchParams.set("link", e + 1),
                        history.pushState({}, null, s.href)
                    }
                    c.value = e,
                    t("play", s.url)
                }
                  , o = async()=>{
                    let s = await Z.fetchStream(i.match_id);
                    s && s.play_urls && (l.value = s.play_urls)
                }
                ;
                await o();
                const d = setInterval((async function() {
                    await o()
                }
                ), 3e4)
                  , m = new URL(window.location.href);
                let v = "1";
                null !== m.searchParams.get("link") && (v = m.searchParams.get("link"));
                let u = parseInt(v) - 1;
                return u >= 0 && l.value.length > 0 && (u > l.value.length - 1 ? (u = 0,
                c.value = u,
                r(l.value[u], u, !0)) : (c.value = u,
                r(l.value[u], u, !1))),
                {
                    iSync: d,
                    play: r,
                    active_index: c,
                    store: e,
                    modelId: n,
                    play_urls: l
                }
            },
            emits: ["play"],
            methods: {},
            beforeUnmount() {
                try {
                    this.iSync && clearInterval(this.iSync)
                } catch (s) {}
            }
        };
        const Gn = (0,
        ls.Z)(Jn, [["render", Vn]]);
        var Qn = Gn;
        const Xn = {
            class: "server-wrap"
        }
          , sl = (0,
        n._)("div", {
            class: "ajax-loading is-load-servers"
        }, [(0,
        n._)("div", {
            class: "vir-item"
        }), (0,
        n._)("div", {
            class: "vir-item"
        }), (0,
        n._)("div", {
            class: "vir-item"
        })], -1)
          , tl = [sl];
        function el(s, t, e, i, a, l) {
            return (0,
            n.wg)(),
            (0,
            n.iD)("div", Xn, tl)
        }
        var il = {
            name: "PlayerToolbarLoading"
        };
        const al = (0,
        ls.Z)(il, [["render", el]]);
        var nl = al
          , ll = {
            name: "PlayerToolbarApp",
            emits: ["play"],
            components: {
                PlayerToolbarLoading: nl,
                PlayerToolbar: Qn
            },
            setup() {
                const s = ja()
                  , {is_show_chat: t} = (0,
                a.Jk)(s)
                  , e = (0,
                w.iH)(!1);
                return {
                    is_fullscreen_mode: e,
                    is_show_chat: t
                }
            },
            methods: {
                play(s) {
                    this.$emit("play", s)
                },
                toggleChat() {
                    this.is_show_chat = !this.is_show_chat
                },
                toggleFullscreen() {
                    const s = window.document.getElementsByTagName("body");
                    s && s.length > 0 && (s[0].classList.toggle("extend-full"),
                    this.is_fullscreen_mode = s[0].classList.contains("extend-full"))
                }
            }
        };
        const cl = (0,
        ls.Z)(ll, [["render", Tn]]);
        var rl = cl;
        const ol = {
            id: "show-countdown"
        }
          , dl = {
            class: "sc-title"
        }
          , ml = {
            key: 0
        }
          , vl = {
            key: 1
        }
          , ul = {
            key: 2
        }
          , hl = {
            key: 0,
            class: "sc-content"
        }
          , _l = {
            id: "day"
        }
          , gl = {
            id: "hour"
        }
          , wl = {
            id: "minute"
        }
          , pl = {
            id: "second"
        };
        function yl(s, t, e, a, l, c) {
            return (0,
            n.wg)(),
            (0,
            n.iD)("div", ol, [(0,
            n._)("div", dl, [c.item.isEnd() ? ((0,
            n.wg)(),
            (0,
            n.iD)("div", ml, "This match is over")) : a.isStart ? ((0,
            n.wg)(),
            (0,
            n.iD)("div", ul, "This match is going on")) : ((0,
            n.wg)(),
            (0,
            n.iD)("div", vl, "This match will begin soon"))]), a.isStart ? (0,
            n.kq)("", !0) : ((0,
            n.wg)(),
            (0,
            n.iD)("div", hl, [(0,
            n.wy)((0,
            n._)("div", null, [(0,
            n._)("div", _l, (0,
            M.zw)(c.showNumber(a.days)), 1), (0,
            n._)("span", null, "Day" + (0,
            M.zw)(c.getMultiString(a.days)), 1)], 512), [[i.F8, a.days > 0]]), (0,
            n._)("div", null, [(0,
            n._)("div", gl, (0,
            M.zw)(c.showNumber(a.hours)), 1), (0,
            n._)("span", null, "Hour" + (0,
            M.zw)(c.getMultiString(a.hours)), 1)]), (0,
            n._)("div", null, [(0,
            n._)("div", wl, (0,
            M.zw)(c.showNumber(a.minutes)), 1), (0,
            n._)("span", null, "Minute" + (0,
            M.zw)(c.getMultiString(a.minutes)), 1)]), (0,
            n.wy)((0,
            n._)("div", null, [(0,
            n._)("div", pl, (0,
            M.zw)(c.showNumber(a.seconds)), 1), (0,
            n._)("span", null, "Second" + (0,
            M.zw)(c.getMultiString(a.seconds)), 1)], 512), [[i.F8, a.days <= 0]])]))])
        }
        var fl = {
            name: "MatchPlayerCountDown",
            props: ["timestamp"],
            setup(s) {
                const t = S()
                  , e = ja()
                  , {match_id: i} = (0,
                a.Jk)(e)
                  , n = (0,
                w.iH)(0)
                  , l = (0,
                w.iH)(0)
                  , c = (0,
                w.iH)(0)
                  , r = (0,
                w.iH)(0)
                  , o = (0,
                w.iH)(!0);
                let d = null;
                function m() {
                    const t = (new Date).getTime()
                      , e = s.timestamp - t;
                    e <= 0 ? (d && clearInterval(d),
                    o.value = !0) : o.value = !1,
                    n.value = Math.floor(e / 864e5),
                    l.value = Math.floor(e % 864e5 / 36e5),
                    c.value = Math.floor(e % 36e5 / 6e4),
                    r.value = Math.floor(e % 6e4 / 1e3)
                }
                return m(),
                d = setInterval((function() {
                    m()
                }
                ), 1e3),
                {
                    store: t,
                    modelId: i,
                    iCount: d,
                    days: n,
                    hours: l,
                    minutes: c,
                    seconds: r,
                    isStart: o
                }
            },
            computed: {
                item() {
                    return this.store.db[this.modelId]
                }
            },
            methods: {
                getMultiString(s) {
                    return s > 1 ? "s" : ""
                },
                showNumber(s) {
                    return s > 9 && s >= 0 ? "" + s : "0" + s
                }
            },
            beforeUnmount() {
                clearInterval(this.iCount)
            }
        };
        const bl = (0,
        ls.Z)(fl, [["render", yl]]);
        var kl = bl
          , jl = {
            name: "MatchPlayer",
            components: {
                MatchPlayerCountDown: kl,
                PlayerToolbarApp: rl
            },
            setup() {
                const s = S()
                  , t = ja()
                  , {match_id: e} = (0,
                a.Jk)(t)
                  , i = (0,
                w.iH)(!1)
                  , n = (0,
                w.iH)(null)
                  , l = (0,
                w.iH)(!1)
                  , c = (0,
                w.iH)(!0)
                  , r = 10
                  , o = (0,
                w.iH)(0);
                return {
                    is_playing: l,
                    max_retry: r,
                    retry_count: o,
                    first_run: c,
                    store: s,
                    modelId: e,
                    player: n,
                    player_created: i
                }
            },
            computed: {
                item() {
                    return this.store.db[this.modelId]
                }
            },
            methods: {
                removePlayer() {
                    this.player && this.player.remove(),
                    this.player = null,
                    window.player = null
                },
                handlePlay(s, t=!0) {
                    this.first_run = t,
                    t && (this.retry_count = 0,
                    this.is_playing = !1),
                    this.removePlayer();
                    const e = window.jwplayer("jw-container")
                      , i = !0;
                    e.setup({
                        title: `${this.item.home.name} - ${this.item.away.name}`,
                        sources: [{
                            file: s
                        }],
                        swarmId: `${this.item.id}` + s,
                        cast: {},
                        autostart: i,
                        preload: "auto",
                        sharing: {
                            sites: ["reddit", "facebook", "twitter"]
                        },
                        width: "100%",
                        height: "100%",
                        primary: "html5",
                        advertising: {
                            withCredentials: !1,
                            autoplayadsmuted: !1,
                            client: "vast",
                            preloadAds: !0,
                            rules: {
                                startOnSeek: "none",
                                timeBetweenAds: 60
                            },
                            schedule: [],
                            vpaidcontrols: !0,
                            vpaidmode: "insecure"
                        }
                    });
                    const a = this
                      , n = ()=>{
                        a.retry_count < a.max_retry && (a.retry_count++,
                        a.is_playing || (console.log("retrying ..... " + a.retry_count),
                        e.load([{
                            file: s
                        }]),
                        e.play()))
                    }
                    ;
                    e.on("error", (function(s) {
                        a.is_playing = !1,
                        console.error(s),
                        setTimeout((function() {
                            n()
                        }
                        ), 4e3)
                    }
                    )).on("play", (function() {
                        a.first_run = !1,
                        a.is_playing = !0,
                        a.retry_count = 0,
                        console.log("play")
                    }
                    )),
                    e.on("buffer", (function(s) {
                        a.is_playing = !1;
                        const {oldstate: t, newstate: e, reason: i} = s;
                        a.first_run || (console.log("on buffering", {
                            oldstate: t,
                            newstate: e,
                            reason: i
                        }),
                        setTimeout((function() {
                            n()
                        }
                        ), 2e4))
                    }
                    )),
                    window.player = e,
                    this.player = e,
                    this.player_created = !0
                }
            },
            beforeUnmount() {
                this.removePlayer()
            }
        };
        const Dl = (0,
        ls.Z)(jl, [["render", Cn]]);
        var Hl = Dl;
        const zl = {
            class: "match-stats"
        }
          , xl = {
            key: 0,
            class: "item"
        }
          , Zl = {
            class: "is-home"
        }
          , Sl = {
            class: "is-title"
        }
          , Ml = {
            class: "is-away"
        };
        function Cl(s, t, e, i, a, l) {
            return (0,
            n.wg)(),
            (0,
            n.iD)("div", zl, [l.item && l.item.stats && l.item.stats.length ? ((0,
            n.wg)(!0),
            (0,
            n.iD)(n.HY, {
                key: 0
            }, (0,
            n.Ko)(l.item.stats, (s=>((0,
            n.wg)(),
            (0,
            n.iD)(n.HY, {
                key: s
            }, [s.can_show ? ((0,
            n.wg)(),
            (0,
            n.iD)("div", xl, [(0,
            n._)("div", Zl, (0,
            M.zw)(s.home_value), 1), (0,
            n._)("div", Sl, (0,
            M.zw)(s.description), 1), (0,
            n._)("div", Ml, (0,
            M.zw)(s.away_value), 1)])) : (0,
            n.kq)("", !0)], 64)))), 128)) : (0,
            n.kq)("", !0)])
        }
        var Il = {
            name: "MatchStats",
            setup() {
                const s = S()
                  , t = ja()
                  , {match_id: e} = (0,
                a.Jk)(t);
                return {
                    store: s,
                    match_id: e
                }
            },
            computed: {
                item() {
                    return this.store.db[this.match_id]
                }
            }
        };
        const El = (0,
        ls.Z)(Il, [["render", Cl]]);
        var Ll = El;
        const Pl = {
            key: 0,
            class: "match-countdown"
        }
          , Tl = (0,
        n._)("div", {
            class: "text-countdown"
        }, "This match will begin soon", -1)
          , Yl = {
            class: "cd-wrap"
        }
          , Fl = {
            class: "time-block"
        }
          , Nl = {
            class: "time-block"
        }
          , Al = {
            class: "time-block"
        }
          , Wl = {
            class: "time-block"
        };
        function Rl(s, t, e, a, l, c) {
            return a.isStart ? (0,
            n.kq)("", !0) : ((0,
            n.wg)(),
            (0,
            n.iD)("div", Pl, [Tl, (0,
            n._)("div", Yl, [(0,
            n.wy)((0,
            n._)("div", Fl, [(0,
            n._)("div", null, (0,
            M.zw)(c.showNumber(a.days)), 1), (0,
            n._)("span", null, "Day" + (0,
            M.zw)(c.getMultiString(a.days)), 1)], 512), [[i.F8, a.days > 0]]), (0,
            n._)("div", Nl, [(0,
            n._)("div", null, (0,
            M.zw)(c.showNumber(a.hours)), 1), (0,
            n._)("span", null, "Hour" + (0,
            M.zw)(c.getMultiString(a.hours)), 1)]), (0,
            n._)("div", Al, [(0,
            n._)("div", null, (0,
            M.zw)(c.showNumber(a.minutes)), 1), (0,
            n._)("span", null, "Minute" + (0,
            M.zw)(c.getMultiString(a.minutes)), 1)]), (0,
            n.wy)((0,
            n._)("div", Wl, [(0,
            n._)("div", null, (0,
            M.zw)(c.showNumber(a.seconds)), 1), (0,
            n._)("span", null, "Second" + (0,
            M.zw)(c.getMultiString(a.seconds)), 1)], 512), [[i.F8, a.days <= 0]])])]))
        }
        var Ul = {
            name: "MatchMiniCountDown",
            props: ["timestamp"],
            setup(s) {
                const t = S()
                  , e = ja()
                  , {match_id: i} = (0,
                a.Jk)(e)
                  , n = (0,
                w.iH)(0)
                  , l = (0,
                w.iH)(0)
                  , c = (0,
                w.iH)(0)
                  , r = (0,
                w.iH)(0)
                  , o = (0,
                w.iH)(!0);
                let d = null;
                function m() {
                    const t = (new Date).getTime()
                      , e = s.timestamp - t;
                    e <= 0 ? (d && clearInterval(d),
                    o.value = !0) : o.value = !1,
                    n.value = Math.floor(e / 864e5),
                    l.value = Math.floor(e % 864e5 / 36e5),
                    c.value = Math.floor(e % 36e5 / 6e4),
                    r.value = Math.floor(e % 6e4 / 1e3)
                }
                return m(),
                d = setInterval((function() {
                    m()
                }
                ), 1e3),
                {
                    store: t,
                    modelId: i,
                    iCount: d,
                    days: n,
                    hours: l,
                    minutes: c,
                    seconds: r,
                    isStart: o
                }
            },
            methods: {
                getMultiString(s) {
                    return s > 1 ? "s" : ""
                },
                showNumber(s) {
                    return s > 9 && s >= 0 ? "" + s : "0" + s
                }
            },
            beforeUnmount() {
                clearInterval(this.iCount)
            }
        };
        const Bl = (0,
        ls.Z)(Ul, [["render", Rl]]);
        var Ol = Bl
          , $l = {
            name: "MatchDetail",
            components: {
                MatchChatBox: xn,
                MatchPlayer: Hl,
                MatchStats: Ll,
                MatchMiniCountDown: Ol
            },
            async setup() {
                const s = S()
                  , t = ja()
                  , {match_id: e} = (0,
                a.Jk)(t)
                  , i = (0,
                w.iH)(null);
                let n = await Z.fetchDetail(t.match_id);
                
                i.value = n,
                await s.addData(n, {
                    source: "detail"
                });
                const l = (0,
                w.iH)(window.seo_data);
                return {
                    seo: l,
                    modelId: e,
                    store: s,
                    match: i
                }
            },
            computed: {
                item() {
                    return this.store.db[this.modelId]
                }
            }
        };
        const ql = (0,
        ls.Z)($l, [["render", wn]]);
        var Kl = ql;
        const Vl = {
            class: "match-wrap"
        }
          , Jl = (0,
        n.uE)('<div class="container"><section class="match-section"><div class="ms-detail"><div class="msd-title"><div class="ajax-loading is-load-single"><div class="vir-item h-30"></div><div class="vir-item h-30"></div></div></div><div class="msd-teams"><div class="ajax-loading is-load-match-team"><div class="vir-item"></div><div class="vir-item"></div></div></div><div class="msd-info"><div class="match-stats"><div class="ajax-loading is-load-single"><div class="vir-item h-30 m-0 mb-3"></div><div class="vir-item h-30 m-0 mb-3"></div><div class="vir-item h-30 m-0"></div></div></div><div class="league-detail"><div class="ajax-loading is-load-single"><div class="vir-item h-30 m-0 mb-3"></div><div class="vir-item h-30 m-0 mb-3"></div><div class="vir-item h-30 m-0"></div></div></div></div></div><div class="ms-media"><div class="media-side"><div class="match-side-head"><div class="ajax-loading is-load-title"><div class="vir-item h-30"></div></div></div><div class="match-social"></div></div><div class="media-frame"><div class="box-countdown"><div id="show-countdown"><div class="sc-title"><div></div></div></div></div></div><div class="media-side"><div class="server-wrap"><div class="ajax-loading is-load-servers"><div class="vir-item"></div><div class="vir-item"></div><div class="vir-item"></div></div></div><div class="match-extend"><div class="ajax-loading is-load-servers"><div class="vir-item"></div><div class="vir-item mr-0"></div></div></div></div></div><div class="ms-chat"><div class="live-chat"><div class="ls___-chatbox"><div class="chatbox_wrap" style="display:none;"></div><div id="chat_off" style="display:block;"><div class="chat_off-content"><div class="text">Chat is off</div><div id="chat_on" class="sbtn sbtn-sm sbtn-secondary">Show chat</div></div></div></div></div></div></section></div>', 1)
          , Gl = [Jl];
        function Ql(s, t, e, i, a, l) {
            return (0,
            n.wg)(),
            (0,
            n.iD)("div", Vl, Gl)
        }
        var Xl = {
            name: "MatchDetailLoading"
        };
        const sc = (0,
        ls.Z)(Xl, [["render", Ql]]);
        var tc = sc
          , ec = {
            name: "MatchDetailWrapper",
            components: {
                MatchDetail: Kl,
                MatchDetailLoading: tc
            }
        };
        const ic = (0,
        ls.Z)(ec, [["render", Ya]]);
        var ac = ic;
        const nc = (0,
        a.WB)();
        function lc(s, t) {
            x.init(s),
            s.use(Re),
            s.use(Ke),
            s.use(nc).mount(t)
        }
        function cc() {
            const s = (0,
            i.ri)(bs);
            lc(s, "#featured-list")
        }
        function rc() {
            const s = (0,
            i.ri)(ct);
            lc(s, "#wide-results")
        }
        function oc() {
            const s = (0,
            i.ri)(Pe);
            lc(s, "#fixture-list")
        }
        function dc() {
            const s = (0,
            i.ri)(ha);
            lc(s, "#home-standing-app")
        }
        function mc() {
            cc(),
            rc(),
            oc(),
            dc()
        }
        function vc() {
            const s = (0,
            i.ri)(Ta);
            lc(s, "#detail-related-app")
        }
        function uc() {
            const s = (0,
            i.ri)(ac);
            lc(s, "#match-detail-app")
        }
        function hc() {
            vc(),
            uc()
        }
        function _c() {
            "detail" === window.page_name ? hc() : mc()
        }
    }
}]);
//# sourceMappingURL=chunk-common.fa55a7d3.js.map
